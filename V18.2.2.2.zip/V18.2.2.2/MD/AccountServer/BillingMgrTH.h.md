# BillingMgrTH.h

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\AccountServer\BillingMgrTH.h`
Chemin relatif: `AccountServer\BillingMgrTH.h`
Nom du fichier: `BillingMgrTH.h`
Extension originale: `.h`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
#ifndef __BILLINGMGRTH_H__
#define	__BILLINGMGRTH_H__


#endif	// __BILLINGMGR_H__
```
