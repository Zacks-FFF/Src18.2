# BillingMgrTW.cpp

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\AccountServer\BillingMgrTW.cpp`
Chemin relatif: `AccountServer\BillingMgrTW.cpp`
Nom du fichier: `BillingMgrTW.cpp`
Extension originale: `.cpp`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
#include "stdafx.h"
#include "MsgHdr.h"
#include "account.h"
#include "DBManager.h"
#include "dpsrvr.h"
#include "dpdbsrvr.h"

extern	CAccountMng	g_AccountMng;
extern	CDbManager	g_DbManager;
extern	CDPSrvr		g_dpSrvr;
extern	CDPDBSrvr	g_dpDbSrvr;
```
