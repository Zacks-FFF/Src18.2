# dpBilling.cpp

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\AccountServer\dpBilling.cpp`
Chemin relatif: `AccountServer\dpBilling.cpp`
Nom du fichier: `dpBilling.cpp`
Extension originale: `.cpp`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
#include "stdafx.h"
#include "account.h"
#include "dpsrvr.h"
```
