# AccountServer.h

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\AccountServer\AccountServer.h`
Chemin relatif: `AccountServer\AccountServer.h`
Nom du fichier: `AccountServer.h`
Extension originale: `.h`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp

#if !defined(AFX_ACCOUNTSERVER_H__45EBEFD1_E393_4619_9C20_C8B57B140063__INCLUDED_)
#define AFX_ACCOUNTSERVER_H__45EBEFD1_E393_4619_9C20_C8B57B140063__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//#include "resource.h"


#endif // !defined(AFX_ACCOUNTSERVER_H__45EBEFD1_E393_4619_9C20_C8B57B140063__INCLUDED_)
```
