# dpwldsrvr.h

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\AccountServer\dpwldsrvr.h`
Chemin relatif: `AccountServer\dpwldsrvr.h`
Nom du fichier: `dpwldsrvr.h`
Extension originale: `.h`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
#ifndef __DPWLDSRVR_H__
#define	__DPWLDSRVR_H__

#include "dpmng.h"
#include "msghdr.h"


#endif	// __DPWLDSRVR_H__
```
