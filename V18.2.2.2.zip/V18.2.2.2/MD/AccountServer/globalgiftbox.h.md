# globalgiftbox.h

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\AccountServer\globalgiftbox.h`
Chemin relatif: `AccountServer\globalgiftbox.h`
Nom du fichier: `globalgiftbox.h`
Extension originale: `.h`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
#ifndef __GLOBAL_GIFT_BOX_H__
#define	__GLOBAL_GIFT_BOX_H__

#include "ar.h"
#include "buffer.h"

#endif	// __GLOBAL_GIFT_BOX_H__
```
