# BillingMgrTH.cpp

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\AccountServer\BillingMgrTH.cpp`
Chemin relatif: `AccountServer\BillingMgrTH.cpp`
Nom du fichier: `BillingMgrTH.cpp`
Extension originale: `.cpp`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
#include "stdafx.h"
```
