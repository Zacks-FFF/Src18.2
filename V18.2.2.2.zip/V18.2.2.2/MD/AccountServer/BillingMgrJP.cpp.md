# BillingMgrJP.cpp

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\AccountServer\BillingMgrJP.cpp`
Chemin relatif: `AccountServer\BillingMgrJP.cpp`
Nom du fichier: `BillingMgrJP.cpp`
Extension originale: `.cpp`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
#include "stdafx.h"
```
