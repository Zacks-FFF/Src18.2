# AccountServer.rc

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\AccountServer\AccountServer.rc`
Chemin relatif: `AccountServer\AccountServer.rc`
Nom du fichier: `AccountServer.rc`
Extension originale: `.rc`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
// Microsoft Visual C++ generated resource script.
//
#include "resource.h"

#define APSTUDIO_READONLY_SYMBOLS
/////////////////////////////////////////////////////////////////////////////
//
// Generated from the TEXTINCLUDE 2 resource.
//
#define APSTUDIO_HIDDEN_SYMBOLS
#include "windows.h"
#undef APSTUDIO_HIDDEN_SYMBOLS
#include "resource.h"

/////////////////////////////////////////////////////////////////////////////
#undef APSTUDIO_READONLY_SYMBOLS

/////////////////////////////////////////////////////////////////////////////
// Korean resources

#if !defined(AFX_RESOURCE_DLL) || defined(AFX_TARG_KOR)
#ifdef _WIN32
LANGUAGE LANG_KOREAN, SUBLANG_DEFAULT
#pragma code_page(949)
#endif //_WIN32

/////////////////////////////////////////////////////////////////////////////
//
// Dialog
//

IDD_DIALOG_TIME DIALOG  0, 0, 185, 59
STYLE DS_SETFONT | DS_MODALFRAME | WS_POPUP | WS_CAPTION | WS_SYSMENU
CAPTION "Dialog"
FONT 10, "System"
BEGIN
    PUSHBUTTON      "Ok",IDOK,23,38,42,14
    LTEXT           "Year",IDC_STATIC,7,8,17,8
    LTEXT           "Month",IDC_STATIC1,43,8,21,8
    LTEXT           "Day",IDC_STATIC2,77,8,17,8
    LTEXT           "Hour",IDC_STATIC3,112,8,18,8
    LTEXT           "Minute",IDC_STATIC4,146,8,23,8
    EDITTEXT        IDC_EDIT_YEAR,7,20,31,12,ES_CENTER | ES_AUTOHSCROLL | 
                    ES_NUMBER
    EDITTEXT        IDC_EDIT_MONTH,42,20,31,12,ES_CENTER | ES_AUTOHSCROLL | 
                    ES_NUMBER
    EDITTEXT        IDC_EDIT_DAY,77,20,31,12,ES_CENTER | ES_AUTOHSCROLL | 
                    ES_NUMBER
    EDITTEXT        IDC_EDIT_HOUR,112,20,31,12,ES_CENTER | ES_AUTOHSCROLL | 
                    ES_NUMBER
    EDITTEXT        IDC_EDIT_MINUTE,147,20,31,12,ES_CENTER | ES_AUTOHSCROLL | 
                    ES_NUMBER
    PUSHBUTTON      "Cancel",IDCANCEL,73,38,42,14
    PUSHBUTTON      "Clear",IDCLEAR,123,38,42,14
END


/////////////////////////////////////////////////////////////////////////////
//
// DESIGNINFO
//

#ifdef APSTUDIO_INVOKED
GUIDELINES DESIGNINFO 
BEGIN
    IDD_DIALOG_TIME, DIALOG
    BEGIN
        LEFTMARGIN, 7
        RIGHTMARGIN, 178
        TOPMARGIN, 8
        BOTTOMMARGIN, 57
    END
END
#endif    // APSTUDIO_INVOKED

#endif    // Korean resources
/////////////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////////////
// English (U.S.) resources

#if !defined(AFX_RESOURCE_DLL) || defined(AFX_TARG_ENU)
#ifdef _WIN32
LANGUAGE LANG_ENGLISH, SUBLANG_ENGLISH_US
#pragma code_page(1252)
#endif //_WIN32

/////////////////////////////////////////////////////////////////////////////
//
// Dialog
//

IDD_ABOUTBOX DIALOG  22, 17, 230, 75
STYLE DS_SETFONT | DS_MODALFRAME | WS_CAPTION | WS_SYSMENU
CAPTION "About"
FONT 8, "System"
BEGIN
    ICON            IDI_ACCOUNTSERVER,IDC_MYICON,14,9,16,16
    LTEXT           "AccountServer Version 1.0",IDC_STATIC,49,10,119,8,
                    SS_NOPREFIX
    LTEXT           "Copyright (C) 2003",IDC_STATIC,49,20,119,8
    DEFPUSHBUTTON   "OK",IDOK,195,6,30,11,WS_GROUP
END

IDD_DIALOG_MAX_CONN DIALOGEX 0, 0, 116, 42
STYLE DS_SETFONT | DS_MODALFRAME | WS_POPUP | WS_CAPTION | WS_SYSMENU
CAPTION "Max Connection"
FONT 14, "SquireD", 0, 0, 0x1
BEGIN
    DEFPUSHBUTTON   "OK",IDOK,7,23,50,12
    PUSHBUTTON      "Cancel",IDCANCEL,60,23,50,12
    EDITTEXT        IDC_EDIT_MAX_CONN,7,7,103,12,ES_AUTOHSCROLL | ES_NUMBER,
                    WS_EX_CLIENTEDGE | WS_EX_RIGHT | WS_EX_STATICEDGE
END

IDD_DIALOG_TOGGLE DIALOGEX 0, 0, 166, 53
STYLE DS_SETFONT | DS_MODALFRAME | WS_POPUP | WS_CAPTION | WS_SYSMENU
CAPTION "TOGGLE"
FONT 11, "SquireD", 0, 0, 0x1
BEGIN
    DEFPUSHBUTTON   "&Enable",IDOK,7,32,50,14
    PUSHBUTTON      "Cancel",IDCANCEL,109,32,50,14
    EDITTEXT        IDC_EDIT1,7,7,76,12,ES_AUTOHSCROLL | ES_READONLY | NOT 
                    WS_BORDER,WS_EX_DLGMODALFRAME
    EDITTEXT        IDC_EDIT2,83,7,76,12,ES_AUTOHSCROLL | ES_READONLY | NOT 
                    WS_BORDER,WS_EX_DLGMODALFRAME
    PUSHBUTTON      "&Disable",IDC_BUTTON_DISABLE,58,32,50,14
    EDITTEXT        IDC_EDIT3,7,19,76,12,ES_AUTOHSCROLL,WS_EX_CLIENTEDGE | 
                    WS_EX_STATICEDGE
    EDITTEXT        IDC_EDIT4,83,19,76,12,ES_AUTOHSCROLL | ES_NUMBER,
                    WS_EX_CLIENTEDGE | WS_EX_STATICEDGE
END


/////////////////////////////////////////////////////////////////////////////
//
// DESIGNINFO
//

#ifdef APSTUDIO_INVOKED
GUIDELINES DESIGNINFO 
BEGIN
    IDD_DIALOG_MAX_CONN, DIALOG
    BEGIN
        LEFTMARGIN, 7
        RIGHTMARGIN, 109
        TOPMARGIN, 7
        BOTTOMMARGIN, 35
    END

    IDD_DIALOG_TOGGLE, DIALOG
    BEGIN
        LEFTMARGIN, 7
        RIGHTMARGIN, 159
        TOPMARGIN, 7
        BOTTOMMARGIN, 46
    END
END
#endif    // APSTUDIO_INVOKED


/////////////////////////////////////////////////////////////////////////////
//
// Icon
//

// Icon with lowest ID value placed first to ensure application icon
// remains consistent on all systems.
IDI_ACCOUNTSERVER       ICON                    "AccountServer.ICO"
IDI_SMALL               ICON                    "SMALL.ICO"

/////////////////////////////////////////////////////////////////////////////
//
// Menu
//

IDC_ACCOUNTSERVER MENU 
BEGIN
    POPUP "Tool(&T)"
    BEGIN
        MENUITEM "Block External Connection",   IDM_OPT_INTERNAL
        MENUITEM "Allow External Connection",   IDM_OPT_EXTERNAL
        MENUITEM "Limit Max connection",        IDM_OPT_MAX_CONN
        MENUITEM "Import Permitted IP",         IDM_OPT_INTERNAL_IP
        MENUITEM "Edit Multi-Server Configuration", IDM_OPT_TOGGLE
    END
    POPUP "Time"
    BEGIN
        MENUITEM "SetTime",                     IDM_OPT_SETTIME
    END
END


/////////////////////////////////////////////////////////////////////////////
//
// Accelerator
//

IDC_ACCOUNTSERVER ACCELERATORS 
BEGIN
    "?",            IDM_ABOUT,              ASCII,  ALT
    "/",            IDM_ABOUT,              ASCII,  ALT
END


#ifdef APSTUDIO_INVOKED
/////////////////////////////////////////////////////////////////////////////
//
// TEXTINCLUDE
//

2 TEXTINCLUDE 
BEGIN
    "#define APSTUDIO_HIDDEN_SYMBOLS\r\n"
    "#include ""windows.h""\r\n"
    "#undef APSTUDIO_HIDDEN_SYMBOLS\r\n"
    "#include ""resource.h""\r\n"
    "\0"
END

3 TEXTINCLUDE 
BEGIN
    "\r\n"
    "\0"
END

1 TEXTINCLUDE 
BEGIN
    "resource.h\0"
END

#endif    // APSTUDIO_INVOKED


/////////////////////////////////////////////////////////////////////////////
//
// String Table
//

STRINGTABLE 
BEGIN
    IDS_APP_TITLE           "AccountServer"
    IDC_ACCOUNTSERVER       "ACCOUNTSERVER"
END

STRINGTABLE 
BEGIN
    IDS_LANG                "1"
    IDS_SUBLANG             "0"
    IDS_CODEPAGE            "0"
    IDS_2ND_PASSWORD        "0"
END

#endif    // English (U.S.) resources
/////////////////////////////////////////////////////////////////////////////



#ifndef APSTUDIO_INVOKED
/////////////////////////////////////////////////////////////////////////////
//
// Generated from the TEXTINCLUDE 3 resource.
//


/////////////////////////////////////////////////////////////////////////////
#endif    // not APSTUDIO_INVOKED

```
