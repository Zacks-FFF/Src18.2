# dpwldsrvr.cpp

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\AccountServer\dpwldsrvr.cpp`
Chemin relatif: `AccountServer\dpwldsrvr.cpp`
Nom du fichier: `dpwldsrvr.cpp`
Extension originale: `.cpp`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
#include "stdafx.h"
#include "dpwldsrvr.h"
#include "globalgiftbox.h"
```
