# AccountServer.vcxproj

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\AccountServer\AccountServer.vcxproj`
Chemin relatif: `AccountServer\AccountServer.vcxproj`
Nom du fichier: `AccountServer.vcxproj`
Extension originale: `.vcxproj`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```text
<?xml version="1.0" encoding="utf-8"?>
<Project DefaultTargets="Build" xmlns="http://schemas.microsoft.com/developer/msbuild/2003">
  <ItemGroup Label="ProjectConfigurations">
    <ProjectConfiguration Include="Debug|Win32">
      <Configuration>Debug</Configuration>
      <Platform>Win32</Platform>
    </ProjectConfiguration>
    <ProjectConfiguration Include="Release|Win32">
      <Configuration>Release</Configuration>
      <Platform>Win32</Platform>
    </ProjectConfiguration>
  </ItemGroup>
  <PropertyGroup Label="Globals">
    <ProjectGuid>{FF113D29-9F20-4D4D-BF94-26F0C67CB78D}</ProjectGuid>
    <WindowsTargetPlatformVersion>10.0</WindowsTargetPlatformVersion>
    <VCProjectVersion>16.0</VCProjectVersion>
  </PropertyGroup>
  <Import Project="$(VCTargetsPath)\Microsoft.Cpp.Default.props" />
  <PropertyGroup Condition="'$(Configuration)|$(Platform)'=='Release|Win32'" Label="Configuration">
    <ConfigurationType>Application</ConfigurationType>
    <UseDebugLibraries>false</UseDebugLibraries>
    <PlatformToolset>v145</PlatformToolset>
    <WholeProgramOptimization>true</WholeProgramOptimization>
    <CharacterSet>MultiByte</CharacterSet>
  </PropertyGroup>
  <PropertyGroup Condition="'$(Configuration)|$(Platform)'=='Debug|Win32'" Label="Configuration">
    <ConfigurationType>Application</ConfigurationType>
    <UseDebugLibraries>true</UseDebugLibraries>
    <PlatformToolset>v145</PlatformToolset>
    <CharacterSet>MultiByte</CharacterSet>
  </PropertyGroup>
  <Import Project="$(VCTargetsPath)\Microsoft.Cpp.props" />
  <ImportGroup Label="ExtensionSettings">
  </ImportGroup>
  <ImportGroup Label="Shared">
  </ImportGroup>
  <ImportGroup Label="PropertySheets" Condition="'$(Configuration)|$(Platform)'=='Debug|Win32'">
    <Import Project="$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props" Condition="exists('$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props')" Label="LocalAppDataPlatform" />
  </ImportGroup>
  <ImportGroup Label="PropertySheets" Condition="'$(Configuration)|$(Platform)'=='Release|Win32'">
    <Import Project="$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props" Condition="exists('$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props')" Label="LocalAppDataPlatform" />
  </ImportGroup>
  <PropertyGroup Label="UserMacros" />
  <PropertyGroup Condition="'$(Configuration)|$(Platform)'=='Debug|Win32'">
    <LinkIncremental>true</LinkIncremental>
    <OutDir>$(SolutionDir)bin\$(Configuration)\$(ProjectName)\</OutDir>
    <IntDir>$(SolutionDir)bin\$(Configuration)\$(ProjectName)\int\</IntDir>
  </PropertyGroup>
  <PropertyGroup Condition="'$(Configuration)|$(Platform)'=='Release|Win32'">
    <LinkIncremental>false</LinkIncremental>
    <OutDir>$(SolutionDir)bin\$(Configuration)\$(ProjectName)\</OutDir>
    <IntDir>$(SolutionDir)bin\$(Configuration)\$(ProjectName)\int\</IntDir>
  </PropertyGroup>
  <ItemDefinitionGroup Condition="'$(Configuration)|$(Platform)'=='Debug|Win32'">
    <ClCompile>
<AdditionalIncludeDirectories>..\..\resource;..\_network;..\_Network\Net2\Include;..\_Network\Misc\Include;.;..\_Network\Mcl\Include;..\_DirectX;..\_Common;..\_database;..\DX_SDK;..\ThirdParty\spdlog\include</AdditionalIncludeDirectories>
      <PreprocessorDefinitions>WIN32;_DEBUG;_WINDOWS;_CRT_SECURE_NO_WARNINGS;NO_WARN_MBCS_MFC_DEPRECATION;_WINSOCK_DEPRECATED_NO_WARNINGS</PreprocessorDefinitions>
      <PrecompiledHeader>Use</PrecompiledHeader>
      <PrecompiledHeaderFile>stdafx.h</PrecompiledHeaderFile>
      <WarningLevel>Level3</WarningLevel>
      <SDLCheck>false</SDLCheck>
      <RuntimeLibrary>MultiThreadedDebug</RuntimeLibrary>
      <AdditionalOptions>/Zc:threadSafeInit- %(AdditionalOptions)</AdditionalOptions>
    </ClCompile>
    <Link>
      <AdditionalDependencies>ws2_32.lib;winmm.lib;d3dx9.lib;odbc32.lib;odbccp32.lib;VERSION.LIB</AdditionalDependencies>
      <AdditionalLibraryDirectories>..\Lib</AdditionalLibraryDirectories>
      <GenerateDebugInformation>true</GenerateDebugInformation>
      <SubSystem>Windows</SubSystem>
    </Link>
    <ResourceCompile>
      <Culture>0x0412</Culture>
    </ResourceCompile>
  </ItemDefinitionGroup>
  <ItemDefinitionGroup Condition="'$(Configuration)|$(Platform)'=='Release|Win32'">
    <ClCompile>
      <AdditionalIncludeDirectories>..\..\resource;..\_network;..\_Network\Net2\Include;..\_Network\Misc\Include;.;..\_Network\Mcl\Include;..\_DirectX;..\_Common;..\_database;..\DX_SDK;..\ThirdParty\spdlog\include</AdditionalIncludeDirectories>
      <PreprocessorDefinitions>WIN32;NDEBUG;_WINDOWS;_CRT_SECURE_NO_WARNINGS;NO_WARN_MBCS_MFC_DEPRECATION;_WINSOCK_DEPRECATED_NO_WARNINGS</PreprocessorDefinitions>
      <IntrinsicFunctions>true</IntrinsicFunctions>
      <FunctionLevelLinking>true</FunctionLevelLinking>
      <PrecompiledHeader>Use</PrecompiledHeader>
      <PrecompiledHeaderFile>stdafx.h</PrecompiledHeaderFile>
      <WarningLevel>Level1</WarningLevel>
      <SDLCheck>false</SDLCheck>
      <RuntimeLibrary>MultiThreaded</RuntimeLibrary>
      <AdditionalOptions>/Zc:threadSafeInit- %(AdditionalOptions)</AdditionalOptions>
    </ClCompile>
    <Link>
      <AdditionalDependencies>ws2_32.lib;winmm.lib;d3dx9.lib;odbc32.lib;odbccp32.lib;VERSION.LIB</AdditionalDependencies>
      <AdditionalLibraryDirectories>..\Lib</AdditionalLibraryDirectories>
      <GenerateDebugInformation>DebugFull</GenerateDebugInformation>
      <SubSystem>Windows</SubSystem>
      <EnableCOMDATFolding>
      </EnableCOMDATFolding>
      <OptimizeReferences>
      </OptimizeReferences>
      <LinkTimeCodeGeneration />
      <LinkTimeCodeGenerationObjectFile />
    </Link>
    <ResourceCompile>
      <Culture>0x0412</Culture>
    </ResourceCompile>
  </ItemDefinitionGroup>
  <ItemGroup>
    <ClCompile Include="account.cpp">
    </ClCompile>
    <ClCompile Include="AccountServer.cpp">
    </ClCompile>
    <ClCompile Include="DBManager.cpp">
    </ClCompile>
    <ClCompile Include="dpdbsrvr.cpp">
    </ClCompile>
    <ClCompile Include="dpsrvr.cpp">
    </ClCompile>
    <ClCompile Include="dpwldsrvr.cpp">
    </ClCompile>
    <ClCompile Include="globalgiftbox.cpp">
    </ClCompile>
    <ClCompile Include="StdAfx.cpp">
      <PrecompiledHeader Condition="'$(Configuration)|$(Platform)'=='Release|Win32'">Create</PrecompiledHeader>
      <PrecompiledHeader Condition="'$(Configuration)|$(Platform)'=='Debug|Win32'">Create</PrecompiledHeader>
    </ClCompile>
    <ClCompile Include="..\_network\misc\src\ar.cpp">
    </ClCompile>
    <ClCompile Include="..\_Network\Misc\Src\heapmng.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\misc\src\mytrace.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\net2\src\buffer.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\net2\src\crc.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\net2\src\sock.cpp">
    </ClCompile>
    <ClCompile Include="..\_directx\dxutil.cpp">
    </ClCompile>
    <ClCompile Include="..\_common\debug.cpp">
    </ClCompile>
    <ClCompile Include="..\_common\file.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\memtrace.cpp">
    </ClCompile>
    <ClCompile Include="..\_common\scanner.cpp">
    </ClCompile>
    <ClCompile Include="..\_common\timer.cpp">
    </ClCompile>
    <ClCompile Include="..\_common\vutil.cpp">
    </ClCompile>
    <ClCompile Include="..\_common\xutil.cpp">
    </ClCompile>
    <ClCompile Include="..\_Database\des.c">
      <PrecompiledHeader Condition="'$(Configuration)|$(Platform)'=='Release|Win32'">
      </PrecompiledHeader>
      <PrecompiledHeader Condition="'$(Configuration)|$(Platform)'=='Debug|Win32'">
      </PrecompiledHeader>
    </ClCompile>
    <ClCompile Include="..\_Database\Query.cpp">
    </ClCompile>
    <ClCompile Include="BillingMgr.cpp">
    </ClCompile>
    <ClCompile Include="BillingMgrJP.cpp">
    </ClCompile>
    <ClCompile Include="BillingMgrJP2.cpp">
    </ClCompile>
    <ClCompile Include="BillingMgrTH.cpp">
    </ClCompile>
    <ClCompile Include="BillingMgrTW.cpp">
    </ClCompile>
    <ClCompile Include="dpadbill.cpp">
    </ClCompile>
    <ClCompile Include="dpBilling.cpp">
    </ClCompile>
	<ClCompile Include="dpBillingTH.cpp">
	</ClCompile>
<ClCompile Include="..\_Common\ZckSpdLog.cpp">
  <PrecompiledHeader>NotUsing</PrecompiledHeader>
  <AdditionalIncludeDirectories>..\ThirdParty\spdlog\include;%(AdditionalIncludeDirectories)</AdditionalIncludeDirectories>
  <AdditionalOptions>/EHsc /utf-8 /Zc:__cplusplus %(AdditionalOptions)</AdditionalOptions>
</ClCompile>
	</ItemGroup>
    <ItemGroup>
    <ResourceCompile Include="AccountServer.rc" />
  </ItemGroup>
  <ItemGroup>
    <ClInclude Include="account.h" />
    <ClInclude Include="AccountServer.h" />
    <ClInclude Include="DBManager.h" />
    <ClInclude Include="dpdbsrvr.h" />
    <ClInclude Include="dpsrvr.h" />
    <ClInclude Include="dpwldsrvr.h" />
    <ClInclude Include="globalgiftbox.h" />
    <ClInclude Include="resource.h" />
    <ClInclude Include="StdAfx.h" />
    <ClInclude Include="VersionCommon.h" />
    <ClInclude Include="..\_network\cmnhdr.h" />
    <ClInclude Include="..\_network\msghdr.h" />
    <ClInclude Include="..\_network\mcl\include\cmcl.h" />
    <ClInclude Include="..\_network\mcl\include\cmclautolock.h" />
    <ClInclude Include="..\_network\mcl\include\cmclcritsec.h" />
    <ClInclude Include="..\_network\misc\include\ar.h" />
    <ClInclude Include="..\_network\misc\include\heapmng.h" />
    <ClInclude Include="..\_network\misc\include\mempooler.h" />
    <ClInclude Include="..\_network\misc\include\misc.h" />
    <ClInclude Include="..\_network\misc\include\mymap.h" />
    <ClInclude Include="..\_network\misc\include\mytrace.h" />
    <ClInclude Include="..\_network\net2\include\buffer.h" />
    <ClInclude Include="..\_network\net2\include\clientsock.h" />
    <ClInclude Include="..\_network\net2\include\clientsocke.h" />
    <ClInclude Include="..\_network\net2\include\crc.h" />
    <ClInclude Include="..\_network\net2\include\dpmng.h" />
    <ClInclude Include="..\_network\net2\include\dpsock.h" />
    <ClInclude Include="..\_network\net2\include\serversock.h" />
    <ClInclude Include="..\_network\net2\include\serversocke.h" />
    <ClInclude Include="..\_network\net2\include\sock.h" />
    <ClInclude Include="..\_Common\DefineCommon.h" />
    <ClInclude Include="..\_directx\dxutil.h" />
    <ClInclude Include="..\_common\buyinginfo.h" />
    <ClInclude Include="..\_common\data.h" />
    <ClInclude Include="..\_common\debug.h" />
    <ClInclude Include="..\_common\file.h" />
    <ClInclude Include="..\_Common\memtrace.h" />
    <ClInclude Include="..\_common\scanner.h" />
    <ClInclude Include="..\_common\timer.h" />
    <ClInclude Include="..\_common\vutil.h" />
    <ClInclude Include="..\_common\xutil.h" />
    <ClInclude Include="..\_Database\des.h" />
    <ClInclude Include="..\_Database\Query.h" />
    <ClInclude Include="BillingMgr.h" />
    <ClInclude Include="BillingMgrJP.h" />
    <ClInclude Include="BillingMgrJP2.h" />
    <ClInclude Include="BillingMgrTH.h" />
    <ClInclude Include="BillingMgrTW.h" />
    <ClInclude Include="dpadbill.h" />
    <ClInclude Include="dpBilling.h" />
    <ClInclude Include="dpBillingTH.h" />
	<ClInclude Include="..\_Common\ZckSpdLog.h" />
  </ItemGroup>
  <ItemGroup>
    <Image Include="AccountServer.ico" />
    <Image Include="small.ico" />
  </ItemGroup>
  <ItemGroup>
    <None Include="AccountServer.ini" />
  </ItemGroup>
  <Import Project="$(VCTargetsPath)\Microsoft.Cpp.targets" />
  <ImportGroup Label="ExtensionTargets">
  </ImportGroup>
</Project>
```
