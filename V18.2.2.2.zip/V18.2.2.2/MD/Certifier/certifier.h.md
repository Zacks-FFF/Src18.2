# certifier.h

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\Certifier\certifier.h`
Chemin relatif: `Certifier\certifier.h`
Nom du fichier: `certifier.h`
Extension originale: `.h`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp

#if !defined(AFX_CERTIFIIER_H__47D7A63E_CFCF_4506_84B8_1A134F691E6E__INCLUDED_)
#define AFX_CERTIFIIER_H__47D7A63E_CFCF_4506_84B8_1A134F691E6E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"


#endif // !defined(AFX_CERTIFIIER_H__47D7A63E_CFCF_4506_84B8_1A134F691E6E__INCLUDED_)
```
