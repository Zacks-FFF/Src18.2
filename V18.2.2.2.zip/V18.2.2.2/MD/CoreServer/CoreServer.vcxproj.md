# CoreServer.vcxproj

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\CoreServer\CoreServer.vcxproj`
Chemin relatif: `CoreServer\CoreServer.vcxproj`
Nom du fichier: `CoreServer.vcxproj`
Extension originale: `.vcxproj`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```text
<?xml version="1.0" encoding="utf-8"?>
<Project DefaultTargets="Build" xmlns="http://schemas.microsoft.com/developer/msbuild/2003">
  <ItemGroup Label="ProjectConfigurations">
    <ProjectConfiguration Include="Debug|Win32">
      <Configuration>Debug</Configuration>
      <Platform>Win32</Platform>
    </ProjectConfiguration>
    <ProjectConfiguration Include="Release|Win32">
      <Configuration>Release</Configuration>
      <Platform>Win32</Platform>
    </ProjectConfiguration>
  </ItemGroup>
  <PropertyGroup Label="Globals">
    <VCProjectVersion>16.0</VCProjectVersion>
    <WindowsTargetPlatformVersion>10.0</WindowsTargetPlatformVersion>
    <ProjectGuid>{E441E1BD-55F2-4649-A7D0-020CA5327C0C}</ProjectGuid>
  </PropertyGroup>
  <Import Project="$(VCTargetsPath)\Microsoft.Cpp.Default.props" />
  <PropertyGroup Condition="'$(Configuration)|$(Platform)'=='Release|Win32'" Label="Configuration">
    <ConfigurationType>Application</ConfigurationType>
    <PlatformToolset>v145</PlatformToolset>
    <UseOfMfc>false</UseOfMfc>
    <CharacterSet>MultiByte</CharacterSet>
    <WholeProgramOptimization>true</WholeProgramOptimization>
  </PropertyGroup>
  <PropertyGroup Condition="'$(Configuration)|$(Platform)'=='Debug|Win32'" Label="Configuration">
    <ConfigurationType>Application</ConfigurationType>
    <UseDebugLibraries>true</UseDebugLibraries>
    <PlatformToolset>v145</PlatformToolset>
    <CharacterSet>MultiByte</CharacterSet>
  </PropertyGroup>
  <Import Project="$(VCTargetsPath)\Microsoft.Cpp.props" />
  <ImportGroup Label="ExtensionSettings">
  </ImportGroup>
  <ImportGroup Label="Shared">
  </ImportGroup>
  <ImportGroup Label="PropertySheets" Condition="'$(Configuration)|$(Platform)'=='Debug|Win32'">
    <Import Project="$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props" Condition="exists('$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props')" Label="LocalAppDataPlatform" />
  </ImportGroup>
  <ImportGroup Label="PropertySheets" Condition="'$(Configuration)|$(Platform)'=='Release|Win32'">
    <Import Project="$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props" Condition="exists('$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props')" Label="LocalAppDataPlatform" />
  </ImportGroup>
  <PropertyGroup Label="UserMacros" />
  <PropertyGroup Condition="'$(Configuration)|$(Platform)'=='Debug|Win32'">
    <LinkIncremental>true</LinkIncremental>
    <IntDir>$(SolutionDir)bin\$(Configuration)\$(ProjectName)\int\</IntDir>
    <OutDir>$(SolutionDir)bin\$(Configuration)\$(ProjectName)\</OutDir>
  </PropertyGroup>
  <PropertyGroup Condition="'$(Configuration)|$(Platform)'=='Release|Win32'">
    <LinkIncremental>false</LinkIncremental>
    <IntDir>$(SolutionDir)bin\$(Configuration)\$(ProjectName)\int\</IntDir>
    <OutDir>$(SolutionDir)bin\$(Configuration)\$(ProjectName)\</OutDir>
  </PropertyGroup>
  <ItemDefinitionGroup Condition="'$(Configuration)|$(Platform)'=='Debug|Win32'">
    <ClCompile>
      <AdditionalIncludeDirectories>..\DX_SDK;.;..\_Network\Net\Include;..\_Network\Misc\Include;..\_Network\Mcl\Include;..\_network;..\_DirectX;..\_Common;..\..\resource;..\_Interface;..\ThirdParty\spdlog\include</AdditionalIncludeDirectories>
      <PreprocessorDefinitions>WIN32;_DEBUG;_WINDOWS;_CRT_SECURE_NO_WARNINGS;NO_WARN_MBCS_MFC_DEPRECATION;_WINSOCK_DEPRECATED_NO_WARNINGS</PreprocessorDefinitions>
      <PrecompiledHeader>Use</PrecompiledHeader>
      <PrecompiledHeaderFile>stdafx.h</PrecompiledHeaderFile>
      <WarningLevel>Level3</WarningLevel>
      <SDLCheck>false</SDLCheck>
      <RuntimeLibrary>MultiThreadedDebug</RuntimeLibrary>
      <AdditionalOptions>/Zc:threadSafeInit- %(AdditionalOptions)</AdditionalOptions>
    </ClCompile>
    <Link>
      <AdditionalDependencies>odbc32.lib;odbccp32.lib;ws2_32.lib;winmm.lib;pdh.lib;VERSION.LIB</AdditionalDependencies>
      <AdditionalLibraryDirectories>..\Lib;..\_Network\Mcl\Lib\Release</AdditionalLibraryDirectories>
      <GenerateDebugInformation>true</GenerateDebugInformation>
      <SubSystem>Windows</SubSystem>
    </Link>
    <ResourceCompile>
      <Culture>0x0412</Culture>
    </ResourceCompile>
  </ItemDefinitionGroup>
  <ItemDefinitionGroup Condition="'$(Configuration)|$(Platform)'=='Release|Win32'">
    <ClCompile>
      <AdditionalIncludeDirectories>..\DX_SDK;.;..\_Network\Net\Include;..\_Network\Misc\Include;..\_Network\Mcl\Include;..\_network;..\_DirectX;..\_Common;..\..\resource;..\_Interface;..\ThirdParty\spdlog\include</AdditionalIncludeDirectories>
      <PreprocessorDefinitions>WIN32;NDEBUG;_WINDOWS;_CRT_SECURE_NO_WARNINGS;NO_WARN_MBCS_MFC_DEPRECATION;_WINSOCK_DEPRECATED_NO_WARNINGS</PreprocessorDefinitions>
      <IntrinsicFunctions>true</IntrinsicFunctions>
      <FunctionLevelLinking>true</FunctionLevelLinking>
      <PrecompiledHeader>Use</PrecompiledHeader>
      <PrecompiledHeaderFile>stdafx.h</PrecompiledHeaderFile>
      <WarningLevel>Level1</WarningLevel>
      <SDLCheck>false</SDLCheck>
      <RuntimeLibrary>MultiThreaded</RuntimeLibrary>
      <AdditionalOptions>/Zc:threadSafeInit- %(AdditionalOptions)</AdditionalOptions>
    </ClCompile>
    <Link>
      <AdditionalDependencies>odbc32.lib;odbccp32.lib;ws2_32.lib;winmm.lib;pdh.lib;VERSION.LIB</AdditionalDependencies>
      <AdditionalLibraryDirectories>..\Lib;..\_Network\Mcl\Lib\Release</AdditionalLibraryDirectories>
      <GenerateDebugInformation>DebugFull</GenerateDebugInformation>
      <SubSystem>Windows</SubSystem>
      <EnableCOMDATFolding>
      </EnableCOMDATFolding>
      <OptimizeReferences>
      </OptimizeReferences>
      <LinkTimeCodeGeneration />
      <LinkTimeCodeGenerationObjectFile />
    </Link>
    <ResourceCompile>
      <Culture>0x0412</Culture>
    </ResourceCompile>
  </ItemDefinitionGroup>
  <ItemGroup>
    <ClCompile Include="..\_Common\ZckAnarchyRank.cpp" />
    <ClCompile Include="CoreServer.cpp">
    </ClCompile>
    <ClCompile Include="DPCacheSrvr.cpp" />
    <ClCompile Include="DPCoreSrvr.cpp">
    </ClCompile>
    <ClCompile Include="DPDatabaseClient.cpp">
    </ClCompile>
    <ClCompile Include="dploginsrvr.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\memtrace.cpp">
    </ClCompile>
    <ClCompile Include="Player.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\playerdata.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\rtmessenger.cpp">
    </ClCompile>
    <ClCompile Include="StdAfx.cpp">
      <PrecompiledHeader Condition="'$(Configuration)|$(Platform)'=='Release|Win32'">Create</PrecompiledHeader>
      <PrecompiledHeader Condition="'$(Configuration)|$(Platform)'=='Debug|Win32'">Create</PrecompiledHeader>
    </ClCompile>
    <ClCompile Include="WantedList.cpp">
    </ClCompile>
    <ClCompile Include="..\_DirectX\dxutil.cpp">
    </ClCompile>
    <ClCompile Include="..\_common\debug.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\Environment.cpp">
    </ClCompile>
    <ClCompile Include="..\_common\file.cpp">
    </ClCompile>
    <ClCompile Include="..\_common\guild.cpp">
    </ClCompile>
    <ClCompile Include="..\_common\guildwar.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\InstanceDungeonBase.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\InstanceDungeonParty.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\messenger.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\party.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\timer.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\vutil.cpp">
    </ClCompile>
    <ClCompile Include="..\_common\xutil.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\scanner.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\net\src\buffer.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\net\src\clientsock.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\net\src\clientsocke.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\net\src\dpmng.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\net\src\dpsock.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\net\src\serversock.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\net\src\serversocke.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\net\src\sock.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\misc\src\ar.cpp">
    </ClCompile>
    <ClCompile Include="..\_Network\Misc\Src\heapmng.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\misc\src\MyTrace.cpp">
    </ClCompile>
	<ClCompile Include="..\_network\misc\src\ServerDesc.cpp">
	</ClCompile>
<ClCompile Include="..\_Common\ZckSpdLog.cpp">
  <PrecompiledHeader>NotUsing</PrecompiledHeader>
  <AdditionalIncludeDirectories>..\ThirdParty\spdlog\include;%(AdditionalIncludeDirectories)</AdditionalIncludeDirectories>
  <AdditionalOptions>/EHsc /utf-8 /Zc:__cplusplus %(AdditionalOptions)</AdditionalOptions>
</ClCompile>
	</ItemGroup>
  <ItemGroup>
    <ResourceCompile Include="CoreServer.rc" />
  </ItemGroup>
  <ItemGroup>
    <ClInclude Include="..\_Common\ZckAnarchyRank.h" />
    <ClInclude Include="CoreServer.h" />
    <ClInclude Include="DPCacheSrvr.h" />
    <ClInclude Include="DPCoreSrvr.h" />
    <ClInclude Include="DPDatabaseClient.h" />
    <ClInclude Include="dploginsrvr.h" />
    <ClInclude Include="..\_Common\memtrace.h" />
    <ClInclude Include="Player.h" />
    <ClInclude Include="resource.h" />
    <ClInclude Include="StdAfx.h" />
    <ClInclude Include="VersionCommon.h" />
    <ClInclude Include="WantedList.h" />
    <ClInclude Include="..\_common\authorization.h" />
    <ClInclude Include="..\_Common\DefineCommon.h" />
    <ClInclude Include="..\_DirectX\dxutil.h" />
    <ClInclude Include="..\_common\buyinginfo.h" />
    <ClInclude Include="..\_Common\data.h" />
    <ClInclude Include="..\_common\debug.h" />
    <ClInclude Include="..\_Common\Environment.h" />
    <ClInclude Include="..\_common\file.h" />
    <ClInclude Include="..\_common\guild.h" />
    <ClInclude Include="..\_common\guildwar.h" />
    <ClInclude Include="..\_Common\InstanceDungeonBase.h" />
    <ClInclude Include="..\_Common\InstanceDungeonParty.h" />
    <ClInclude Include="..\_Common\messenger.h" />
    <ClInclude Include="..\_Common\party.h" />
    <ClInclude Include="..\databaseserver\project.h" />
    <ClInclude Include="..\_common\projectcmn.h" />
    <ClInclude Include="..\_Common\timer.h" />
    <ClInclude Include="..\_Common\vutil.h" />
    <ClInclude Include="..\_common\xutil.h" />
    <ClInclude Include="..\_Common\scanner.h" />
    <ClInclude Include="..\_network\CmnHdr.h" />
    <ClInclude Include="..\_network\MsgHdr.h" />
    <ClInclude Include="..\_network\net\include\buffer.h" />
    <ClInclude Include="..\_network\net\include\clientsock.h" />
    <ClInclude Include="..\_network\net\include\clientsocke.h" />
    <ClInclude Include="..\_network\net\include\dpmng.h" />
    <ClInclude Include="..\_network\net\include\dpsock.h" />
    <ClInclude Include="..\_network\net\include\serversock.h" />
    <ClInclude Include="..\_network\net\include\serversocke.h" />
    <ClInclude Include="..\_network\net\include\sock.h" />
    <ClInclude Include="..\_network\mcl\include\cmcl.h" />
    <ClInclude Include="..\_network\mcl\include\cmclautolock.h" />
    <ClInclude Include="..\_network\mcl\include\cmclcritsec.h" />
    <ClInclude Include="..\_network\misc\include\ar.h" />
    <ClInclude Include="..\_network\misc\include\chassert.h" />
    <ClInclude Include="..\_network\misc\include\heapmng.h" />
    <ClInclude Include="..\_network\misc\include\mempool.h" />
    <ClInclude Include="..\_network\misc\include\MEMPOOLER.H" />
    <ClInclude Include="..\_network\misc\include\memspy.h" />
    <ClInclude Include="..\_network\misc\include\Misc.h" />
    <ClInclude Include="..\_network\misc\include\MyMap.h" />
    <ClInclude Include="..\_network\misc\include\MyTrace.h" />
    <ClInclude Include="..\_network\misc\include\ObjMap.h" />
    <ClInclude Include="..\_network\misc\include\ServerDesc.h" />
    <ClInclude Include="..\_network\misc\include\tickcount.h" />
	<ClInclude Include="..\_Common\ZckSpdLog.h" />
  </ItemGroup>
  <ItemGroup>
    <Text Include="BoA!!!.txt" />
  </ItemGroup>
  <ItemGroup>
    <Image Include="CoreServer.ico" />
    <Image Include="small.ico" />
  </ItemGroup>
  <ItemGroup>
    <None Include="CoreServer.ini" />
  </ItemGroup>
  <Import Project="$(VCTargetsPath)\Microsoft.Cpp.targets" />
  <ImportGroup Label="ExtensionTargets">
  </ImportGroup>
</Project>
```
