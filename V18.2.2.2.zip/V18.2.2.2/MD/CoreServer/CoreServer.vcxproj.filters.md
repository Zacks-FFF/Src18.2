# CoreServer.vcxproj.filters

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\CoreServer\CoreServer.vcxproj.filters`
Chemin relatif: `CoreServer\CoreServer.vcxproj.filters`
Nom du fichier: `CoreServer.vcxproj.filters`
Extension originale: `.filters`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```text
<?xml version="1.0" encoding="utf-8"?>
<Project ToolsVersion="4.0" xmlns="http://schemas.microsoft.com/developer/msbuild/2003">
  <ItemGroup>
    <Filter Include="Source Files">
      <UniqueIdentifier>{4e1c2604-6af2-4ab4-bbcb-de78435e1705}</UniqueIdentifier>
      <Extensions>cpp;c;cxx;rc;def;r;odl;idl;hpj;bat</Extensions>
    </Filter>
    <Filter Include="Header Files">
      <UniqueIdentifier>{ebb75d7b-2986-4f65-a830-1cafb2a44fb4}</UniqueIdentifier>
      <Extensions>h;hpp;hxx;hm;inl</Extensions>
    </Filter>
    <Filter Include="Neuz Common Files">
      <UniqueIdentifier>{1797f4c9-d606-4acf-9549-9cdc9e8c8170}</UniqueIdentifier>
    </Filter>
    <Filter Include="Neuz Common Files\DirectX Files">
      <UniqueIdentifier>{1dd76f7a-4ed2-4c04-bdde-fc0af8bf9df9}</UniqueIdentifier>
    </Filter>
    <Filter Include="Neuz Common Files\Common Files">
      <UniqueIdentifier>{7a09722f-3bad-4f3c-83a4-12349bb0128f}</UniqueIdentifier>
    </Filter>
    <Filter Include="Neuz Common Files\Common Files\Script">
      <UniqueIdentifier>{f0935dd1-4696-44fe-9e7c-8aaec04ccaf4}</UniqueIdentifier>
    </Filter>
    <Filter Include="Network Files">
      <UniqueIdentifier>{99ead81b-372d-4e23-9e8b-1120066823cd}</UniqueIdentifier>
    </Filter>
    <Filter Include="Network Files\Net">
      <UniqueIdentifier>{15e859f4-6d51-4bc0-8f86-63cb4dbaeda5}</UniqueIdentifier>
    </Filter>
    <Filter Include="Network Files\Mcl">
      <UniqueIdentifier>{0dc1b809-6b84-4bb7-ae51-1243daedfe4e}</UniqueIdentifier>
    </Filter>
    <Filter Include="Network Files\Misc">
      <UniqueIdentifier>{e4a89207-e7e7-4b2d-8458-71f4a28876c1}</UniqueIdentifier>
    </Filter>
    <Filter Include="Resource Files">
      <UniqueIdentifier>{6d1f07e3-6584-434b-9d1b-d7879c6e97bd}</UniqueIdentifier>
      <Extensions>ico;cur;bmp;dlg;rc2;rct;bin;rgs;gif;jpg;jpeg;jpe</Extensions>
    </Filter>
  </ItemGroup>
  <ItemGroup>
    <ClCompile Include="CoreServer.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="DPCoreSrvr.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="DPDatabaseClient.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="dploginsrvr.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\memtrace.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="Player.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\playerdata.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\rtmessenger.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="StdAfx.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="WantedList.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_DirectX\dxutil.cpp">
      <Filter>Neuz Common Files\DirectX Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_common\debug.cpp">
      <Filter>Neuz Common Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\Environment.cpp">
      <Filter>Neuz Common Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_common\file.cpp">
      <Filter>Neuz Common Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_common\guild.cpp">
      <Filter>Neuz Common Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_common\guildwar.cpp">
      <Filter>Neuz Common Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\InstanceDungeonBase.cpp">
      <Filter>Neuz Common Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\InstanceDungeonParty.cpp">
      <Filter>Neuz Common Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\messenger.cpp">
      <Filter>Neuz Common Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\party.cpp">
      <Filter>Neuz Common Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\timer.cpp">
      <Filter>Neuz Common Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\vutil.cpp">
      <Filter>Neuz Common Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_common\xutil.cpp">
      <Filter>Neuz Common Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\scanner.cpp">
      <Filter>Neuz Common Files\Common Files\Script</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net\src\buffer.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net\src\clientsock.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net\src\clientsocke.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net\src\dpmng.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net\src\dpsock.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net\src\serversock.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net\src\serversocke.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net\src\sock.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\misc\src\ar.cpp">
      <Filter>Network Files\Misc</Filter>
    </ClCompile>
    <ClCompile Include="..\_Network\Misc\Src\heapmng.cpp">
      <Filter>Network Files\Misc</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\misc\src\MyTrace.cpp">
      <Filter>Network Files\Misc</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\misc\src\ServerDesc.cpp">
      <Filter>Network Files\Misc</Filter>
    </ClCompile>
    <ClCompile Include="DPCacheSrvr.cpp">
      <Filter>Header Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\ZckAnarchyRank.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
  </ItemGroup>
  <ItemGroup>
    <ResourceCompile Include="CoreServer.rc">
      <Filter>Source Files</Filter>
    </ResourceCompile>
  </ItemGroup>
  <ItemGroup>
    <ClInclude Include="CoreServer.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="DPCacheSrvr.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="DPCoreSrvr.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="DPDatabaseClient.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="dploginsrvr.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\memtrace.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="Player.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="resource.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="StdAfx.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="VersionCommon.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="WantedList.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_common\authorization.h">
      <Filter>Neuz Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\DefineCommon.h">
      <Filter>Neuz Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_DirectX\dxutil.h">
      <Filter>Neuz Common Files\DirectX Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_common\buyinginfo.h">
      <Filter>Neuz Common Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\data.h">
      <Filter>Neuz Common Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_common\debug.h">
      <Filter>Neuz Common Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\Environment.h">
      <Filter>Neuz Common Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_common\file.h">
      <Filter>Neuz Common Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_common\guild.h">
      <Filter>Neuz Common Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_common\guildwar.h">
      <Filter>Neuz Common Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\InstanceDungeonBase.h">
      <Filter>Neuz Common Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\InstanceDungeonParty.h">
      <Filter>Neuz Common Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\messenger.h">
      <Filter>Neuz Common Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\party.h">
      <Filter>Neuz Common Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\databaseserver\project.h">
      <Filter>Neuz Common Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_common\projectcmn.h">
      <Filter>Neuz Common Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\timer.h">
      <Filter>Neuz Common Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\vutil.h">
      <Filter>Neuz Common Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_common\xutil.h">
      <Filter>Neuz Common Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\scanner.h">
      <Filter>Neuz Common Files\Common Files\Script</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\CmnHdr.h">
      <Filter>Network Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\MsgHdr.h">
      <Filter>Network Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\buffer.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\clientsock.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\clientsocke.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\dpmng.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\dpsock.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\serversock.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\serversocke.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\sock.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\mcl\include\cmcl.h">
      <Filter>Network Files\Mcl</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\mcl\include\cmclautolock.h">
      <Filter>Network Files\Mcl</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\mcl\include\cmclcritsec.h">
      <Filter>Network Files\Mcl</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\ar.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\chassert.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\heapmng.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\mempool.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\MEMPOOLER.H">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\memspy.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\Misc.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\MyMap.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\MyTrace.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\ObjMap.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\ServerDesc.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\tickcount.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\ZckAnarchyRank.h">
      <Filter>Header Files</Filter>
    </ClInclude>
  </ItemGroup>
  <ItemGroup>
    <Text Include="BoA!!!.txt">
      <Filter>Resource Files</Filter>
    </Text>
  </ItemGroup>
  <ItemGroup>
    <Image Include="CoreServer.ico">
      <Filter>Resource Files</Filter>
    </Image>
    <Image Include="small.ico">
      <Filter>Resource Files</Filter>
    </Image>
  </ItemGroup>
  <ItemGroup>
    <None Include="CoreServer.ini">
      <Filter>Resource Files</Filter>
    </None>
  </ItemGroup>
</Project>
```
