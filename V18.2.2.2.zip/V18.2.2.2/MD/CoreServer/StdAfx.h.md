# StdAfx.h

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\CoreServer\StdAfx.h`
Chemin relatif: `CoreServer\StdAfx.h`
Nom du fichier: `StdAfx.h`
Extension originale: `.h`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
#pragma once

#define WIN32_LEAN_AND_MEAN
#define _USE_32BIT_TIME_T
#define POINTER_64 __ptr64
#define __CORESERVER
#define _WIN32_WINNT 0x0A00 // Windows 10

#include <afxwin.h>

#include <mmsystem.h>
#include <d3dx9math.h>

#pragma warning(disable:4786)
#include <vector>
#include <list>
#include <string>
#include <map>
#include <unordered_map>
#include <array>
#include <queue>
#include <set>
#include <unordered_set>
#include <chrono>
#include <random>
using namespace std;

#include <DPlay.h>
#include "VersionCommon.h"
#include "CustomCommon.h"

#include "memtrace.h"

#include "DefineCommon.h"
#include "CmnHdr.h"
#include "chassert.h"
#include "DXUtil.h"
#include "Data.h"
#include "file.h"
#include "vutil.h"
#include "Scanner.h"
#include "projectcmn.h"
#include "Timer.h"
#include "d3dfont.h"
#include "DefineJob.h"
#include "DefineNeuz.h"
#include "DefineObj.h"
#include "authorization.h"
#include "debug.h"
#include "xutil.h"
#include "tickcount.h"

#include <afxdisp.h>

extern	CTickCount	g_TickCount;
extern	CGameTimer	g_GameTimer;
extern	float		s_fPartyExpRate;
```
