# README

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\lpng1658\contrib\pngsuite\interlaced\README`
Chemin relatif: `lpng1658\contrib\pngsuite\interlaced\README`
Nom du fichier: `README`
Extension originale: `(aucune)`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```text
These images fail the "pngimage-quick" and "pngimage-full" tests.
```
