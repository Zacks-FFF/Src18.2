# bad_interlace_conversions.txt

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\lpng1658\contrib\pngsuite\bad_interlace_conversions.txt`
Chemin relatif: `lpng1658\contrib\pngsuite\bad_interlace_conversions.txt`
Nom du fichier: `bad_interlace_conversions.txt`
Extension originale: `.txt`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```text
basn0g01.png
basn0g02.png
basn0g04.png
basn3p01.png
basn3p02.png
basn3p04.png
ftbbn0g01.png
ftbbn0g02.png
ftbbn0g04.png
```
