# test_pngminus.bat

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\lpng1658\contrib\pngminus\test_pngminus.bat`
Chemin relatif: `lpng1658\contrib\pngminus\test_pngminus.bat`
Nom du fichier: `test_pngminus.bat`
Extension originale: `.bat`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```bat
make
call png2pnm.bat
call pnm2png.bat

```
