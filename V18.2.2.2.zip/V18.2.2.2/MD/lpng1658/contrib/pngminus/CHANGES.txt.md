# CHANGES.txt

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\lpng1658\contrib\pngminus\CHANGES.txt`
Chemin relatif: `lpng1658\contrib\pngminus\CHANGES.txt`
Nom du fichier: `CHANGES.txt`
Extension originale: `.txt`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```text
pnm2png / png2pnm --- conversion from PBM/PGM/PPM-file to PNG-file
copyright (C) 1999-2019 by Willem van Schaik <willem at schaik dot com>

version 1.0 - 1999.10.15 - First version.
        1.1 - 2015.07.29 - Fix memory leaks (Glenn Randers-Pehrson)
        1.2 - 2017.04.22 - Add buffer-size check
        1.3 - 2017.08.24 - Fix potential overflow in buffer-size check
                           (Glenn Randers-Pehrson)
        1.4 - 2017.08.28 - Add PNGMINUS_UNUSED (Christian Hesse)
        1.5 - 2018.08.05 - Fix buffer overflow in tokenizer (Cosmin Truta)
        1.6 - 2018.08.05 - Improve portability and fix style (Cosmin Truta)
        1.7 - 2019.01.22 - Change license to MIT (Willem van Schaik)
        1.8 - 2024.01.09 - Fix, improve, modernize (Cosmin Truta)
        1.9 - 2025.01.10 - Delete conditionally-compiled code (Cosmin Truta)
```
