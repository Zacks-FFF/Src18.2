# README

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\lpng1658\contrib\pngminim\README`
Chemin relatif: `lpng1658\contrib\pngminim\README`
Nom du fichier: `README`
Extension originale: `(aucune)`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```text
This demonstrates the use of PNG_USER_CONFIG, pngusr.h and pngusr.dfa
to build minimal decoder, encoder, and progressive reader applications.

See the individual README and pngusr.dfa files for more explanation.
```
