# CacheServer.vcxproj.filters

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\CacheServer\CacheServer.vcxproj.filters`
Chemin relatif: `CacheServer\CacheServer.vcxproj.filters`
Nom du fichier: `CacheServer.vcxproj.filters`
Extension originale: `.filters`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```text
<?xml version="1.0" encoding="utf-8"?>
<Project ToolsVersion="4.0" xmlns="http://schemas.microsoft.com/developer/msbuild/2003">
  <ItemGroup>
    <Filter Include="Source Files">
      <UniqueIdentifier>{c7bcfb9f-9bad-46c9-b473-38e135e30ce4}</UniqueIdentifier>
      <Extensions>cpp;c;cxx;rc;def;r;odl;idl;hpj;bat</Extensions>
    </Filter>
    <Filter Include="Header Files">
      <UniqueIdentifier>{ba9a8c60-9388-4557-97e3-3720e694f1a2}</UniqueIdentifier>
      <Extensions>h;hpp;hxx;hm;inl</Extensions>
    </Filter>
    <Filter Include="Resource Files">
      <UniqueIdentifier>{fcda8952-379f-4107-a015-ae3530ff2bee}</UniqueIdentifier>
      <Extensions>ico;cur;bmp;dlg;rc2;rct;bin;rgs;gif;jpg;jpeg;jpe</Extensions>
    </Filter>
    <Filter Include="Network Files">
      <UniqueIdentifier>{987df7df-1c0d-4160-9ce4-647281632aa8}</UniqueIdentifier>
    </Filter>
    <Filter Include="Network Files\Net">
      <UniqueIdentifier>{3dacbcca-dcf9-4707-8302-f1a1f53602d0}</UniqueIdentifier>
    </Filter>
    <Filter Include="Network Files\Mcl">
      <UniqueIdentifier>{b97f63f4-a3a6-4049-8621-929dc94fca79}</UniqueIdentifier>
    </Filter>
    <Filter Include="Network Files\Misc">
      <UniqueIdentifier>{f5608fc9-5dce-4e16-938b-b01e64aadfdd}</UniqueIdentifier>
    </Filter>
    <Filter Include="Neuz Common Files">
      <UniqueIdentifier>{467bcf4a-9eb1-41f1-88ec-43771fc2d62c}</UniqueIdentifier>
    </Filter>
    <Filter Include="Neuz Common Files\DirectX Files">
      <UniqueIdentifier>{5a40bbb3-9609-4b00-8b23-83517aec7e9e}</UniqueIdentifier>
    </Filter>
    <Filter Include="Neuz Common Files\Common Files">
      <UniqueIdentifier>{0a109433-82a3-4796-bf3d-a758e3a7854e}</UniqueIdentifier>
    </Filter>
  </ItemGroup>
  <ItemGroup>
    <ClCompile Include="CacheServer.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="crashstatus.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="DPCacheSrvr.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="DPClient.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="DPCoreClient.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\memtrace.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\messenger.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="packetlog.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="Player.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\rtmessenger.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\misc\src\speedhackchecker.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="StdAfx.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_common\vutil.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Network\Net\Src\crc.cpp">
      <Filter>Network Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net\src\buffer.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net\src\clientsock.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net\src\clientsocke.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net\src\dpmng.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net\src\dpsock.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net\src\serversock.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net\src\serversocke.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net\src\sock.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\misc\src\ar.cpp">
      <Filter>Network Files\Misc</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\misc\src\dos2.cpp">
      <Filter>Network Files\Misc</Filter>
    </ClCompile>
    <ClCompile Include="..\_Network\Misc\Src\heapmng.cpp">
      <Filter>Network Files\Misc</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\misc\src\MyTrace.cpp">
      <Filter>Network Files\Misc</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\misc\src\ServerDesc.cpp">
      <Filter>Network Files\Misc</Filter>
    </ClCompile>
    <ClCompile Include="..\_DirectX\dxutil.cpp">
      <Filter>Neuz Common Files\DirectX Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\debug.cpp">
      <Filter>Neuz Common Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_common\file.cpp">
      <Filter>Neuz Common Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\scanner.cpp">
      <Filter>Neuz Common Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\timer.cpp">
      <Filter>Neuz Common Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_common\xutil.cpp">
      <Filter>Neuz Common Files\Common Files</Filter>
    </ClCompile>
  </ItemGroup>
  <ItemGroup>
    <ResourceCompile Include="CacheServer.rc">
      <Filter>Source Files</Filter>
    </ResourceCompile>
  </ItemGroup>
  <ItemGroup>
    <ClInclude Include="CacheServer.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="crashstatus.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="DPCacheSrvr.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="DPClient.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="DPCoreClient.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\memtrace.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\messenger.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="packetlog.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="Player.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="resource.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\speedhackchecker.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="StdAfx.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="VersionCommon.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\CmnHdr.h">
      <Filter>Network Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Network\Net\Include\crc.h">
      <Filter>Network Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\MsgHdr.h">
      <Filter>Network Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\buffer.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\clientsock.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\clientsocke.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\dpmng.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\dpsock.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\serversock.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\serversocke.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\sock.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\mcl\include\cmcl.h">
      <Filter>Network Files\Mcl</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\mcl\include\cmclautolock.h">
      <Filter>Network Files\Mcl</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\mcl\include\cmclcritsec.h">
      <Filter>Network Files\Mcl</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\ar.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\chassert.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\dos2.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\heapmng.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\mempool.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\MEMPOOLER.H">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\memspy.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\misc.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\MyMap.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\MyTrace.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\ObjMap.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\ServerDesc.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\DefineCommon.h">
      <Filter>Neuz Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_DirectX\dxutil.h">
      <Filter>Neuz Common Files\DirectX Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\data.h">
      <Filter>Neuz Common Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\debug.h">
      <Filter>Neuz Common Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_common\file.h">
      <Filter>Neuz Common Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\landscape.h">
      <Filter>Neuz Common Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\scanner.h">
      <Filter>Neuz Common Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\timer.h">
      <Filter>Neuz Common Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_common\xutil.h">
      <Filter>Neuz Common Files\Common Files</Filter>
    </ClInclude>
  </ItemGroup>
  <ItemGroup>
    <Image Include="CacheServer.ico">
      <Filter>Resource Files</Filter>
    </Image>
    <Image Include="small.ico">
      <Filter>Resource Files</Filter>
    </Image>
  </ItemGroup>
  <ItemGroup>
    <None Include="CacheServer.ini">
      <Filter>Resource Files</Filter>
    </None>
  </ItemGroup>
</Project>
```
