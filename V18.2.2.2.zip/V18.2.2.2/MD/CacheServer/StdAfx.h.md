# StdAfx.h

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\CacheServer\StdAfx.h`
Chemin relatif: `CacheServer\StdAfx.h`
Nom du fichier: `StdAfx.h`
Extension originale: `.h`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
#pragma once

#define WIN32_LEAN_AND_MEAN
#define _USE_32BIT_TIME_T
#define __CACHESERVER
#define POINTER_64 __ptr64
#define MASSIVE
#define _WIN32_WINNT 0x0A00 // Windows 10

#include <afxwin.h>

#include <d3dx9math.h>
#include <mmsystem.h>

#pragma warning(disable:4786)
#include <vector>
#include <list>
#include <string>
#include <map>
#include <unordered_map>
#include <array>
#include <queue>
#include <set>
#include <unordered_set>
#include <chrono>
#include <random>
using namespace std;

#include "VersionCommon.h"
#include "CustomCommon.h"
#include "memtrace.h"
#include "DefineCommon.h"
#include "CmnHdr.h"
#include <afxdisp.h>
#include "vutil.h"
#include "DXUtil.h"
#include "Data.h"
#include "File.h"
#include "Scanner.h"
#include "Debug.h"
#include "Timer.h"
#include "d3dfont.h"
#include "xutil.h"
```
