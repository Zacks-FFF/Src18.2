# VersionCommon.h

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\LoginServer\VersionCommon.h`
Chemin relatif: `LoginServer\VersionCommon.h`
Nom du fichier: `VersionCommon.h`
Extension originale: `.h`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
#ifndef __VERSION_COMMON_H__
#define __VERSION_COMMON_H__

#define __MAINSERVER
#if !defined( __TESTSERVER ) && !defined( __MAINSERVER )
	#define __INTERNALSERVER
#endif

#define		__SERVER

#define		__CRC
#define		__SO1014
#define		__PROTOCOL0910
#define		__PROTOCOL1021
#define		__VERIFYNETLIB
#define		__DOS1101
#define		__STL_0402		// stl

#if (_MSC_VER > 1200)
#define		__VS2003
#endif




#if	  defined(__INTERNALSERVER)


#elif defined(__TESTSERVER)


#elif defined(__MAINSERVER)

#endif


#endif

```
