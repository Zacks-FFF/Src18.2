# LoginServer.cpp

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\LoginServer\LoginServer.cpp`
Chemin relatif: `LoginServer\LoginServer.cpp`
Nom du fichier: `LoginServer.cpp`
Extension originale: `.cpp`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
// LoginServer.cpp : Defines the entry point for the application.


#include "stdafx.h"
#ifdef __ZCK_SPD_LOG
#include "ZckSpdLog.h"
#endif // __ZCK_SPD_LOG
#ifdef IDC_STATIC
#undef IDC_STATIC
#endif
#include "resource.h"
#include "dploginsrvr.h"
#include "dpdatabaseclient.h"
#include "dpcoreclient.h"
#include "mytrace.h"
#include "user.h"




extern	CDPLoginSrvr		g_dpLoginSrvr;
extern	CDPDatabaseClient	g_dpDBClient;
extern	CDPCoreClient		g_dpCoreClient;
extern	CMyTrace			g_MyTrace;
extern	CUserMng			g_UserMng;


#define MAX_LOADSTRING 100

HINSTANCE	hInst;	// current instance
TCHAR		szTitle[MAX_LOADSTRING];	// The title bar text
TCHAR		szWindowClass[MAX_LOADSTRING];	// The title bar text
HWND		hMainWnd;


ATOM	MyRegisterClass(HINSTANCE hInstance);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
BOOL	InitInstance(HINSTANCE, int);
void	ExitInstance( void );
BOOL	Script( LPCSTR lpszFileName );


void InitLanguageFromResource( HINSTANCE hInstance )
{
	char szLang[16], szSubLang[16];
	LoadString(hInstance, IDS_LANG, szLang, 16);
	LoadString(hInstance, IDS_SUBLANG, szSubLang, 16);

	char szCodePage[16];
	LoadString(hInstance, IDS_CODEPAGE, szCodePage, 16);
	g_codePage = atoi( szCodePage );

	::SetLanguageInfo( atoi( szLang ), atoi( szSubLang ) );
}

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
#ifdef __ZCK_SPD_LOG
	CZckSpdLogScope zckSpdLogScope;
#endif // __ZCK_SPD_LOG
 	InitLanguageFromResource( hInstance );

	// Initialize global strings
	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, IDC_LOGINSERVER, szWindowClass, MAX_LOADSTRING);
	MyRegisterClass(hInstance);

	// Perform application initialization:
	if (!InitInstance (hInstance, nCmdShow))
		return FALSE;

	MSG msg;
	while (GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	ExitInstance();

	return msg.wParam;
}

ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX);

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= (WNDPROC)WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, (LPCTSTR)IDI_LOGINSERVER);
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= (LPCSTR)IDC_LOGINSERVER;
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, (LPCTSTR)IDI_SMALL);

	return RegisterClassEx(&wcex);
}

BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
	if (!Script("Script\\LoginServer.ini"))
		return FALSE;

	HWND hWnd;

	hInst = hInstance; // Store instance handle in our global variable

	hMainWnd	= hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL);

	if( !hWnd )
	{
		return FALSE;
	}

	SetTimer( hWnd, 0, 60 * 1000, NULL );

	int x = 880, y = 606;
	SetWindowPos( hWnd, NULL, x, y, 400, 416, SWP_SHOWWINDOW );

	g_MyTrace.Initialize( hWnd, "SquireD", RGB( 0x00, 0x00, 0x00 ), RGB( 0xff, 0xff, 0xff ) );

	CTime time	= CTime::GetCurrentTime();
	g_MyTrace.Add( 0, FALSE, "%s", time.Format( "%Y/%m/%d %H:%M:%S" ) );
	g_MyTrace.AddLine( '\0' );

	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);

#ifndef _DEBUG
//   InitEH();
#endif	// _DEBUG

	if( InitializeNetLib() == FALSE )
		return FALSE;
	if( !g_dpDBClient.ConnectToServer( g_lpDBAddr, PN_DBSRVR_0 ) )
	{
		return FALSE;
	}

	if( !g_dpCoreClient.ConnectToServer( g_lpCoreAddr, PN_CORESRVR + 2 ) )
	{
		return FALSE;
	}
	g_dpCoreClient.QueryTickCount();	// block,

#ifdef __CRC
	if( !g_dpLoginSrvr.StartServer( PN_LOGINSRVR, FALSE, CSock::crcRead ) )
#else	// __CRC
	if( !g_dpLoginSrvr.StartServer( PN_LOGINSRVR ) )
#endif	// __CRC
		return FALSE;

#ifdef __ZCK_SPD_LOG
	ZCK_LOG_INFO("LoginServer initialisé.");
#endif // __ZCK_SPD_LOG
	return TRUE;
}

void ExitInstance( void )
{
	g_dpLoginSrvr.DeleteDPObject();
	g_dpCoreClient.DeleteDPObject();
	g_dpDBClient.DeleteDPObject();
	g_UserMng.Free();
	SAFE_DELETE( CUser::m_pPool );

	UninitializeNetLib();
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int wmId, wmEvent;
	PAINTSTRUCT ps;
	HDC hdc;

	switch (message)
	{
		case WM_COMMAND:
			wmId    = LOWORD(wParam);
			wmEvent = HIWORD(wParam);
			// Parse the menu selections:
			switch (wmId)
			{
				case IDM_ABOUT:
				   break;
				case IDM_EXIT:
				   DestroyWindow(hWnd);
				   break;
				default:
				   return DefWindowProc(hWnd, message, wParam, lParam);
			}
			break;
		case WM_TIMER:
			{
				WORD wTimerID	= wParam;
				switch( wTimerID )
				{
					case 0:
						g_UserMng.DestroyAbnormalPlayer();
						break;
				}
				break;
			}
		case WM_PAINT:
			hdc = BeginPaint(hWnd, &ps);
			g_MyTrace.Paint( hdc );
			EndPaint(hWnd, &ps);
			break;
		case WM_DESTROY:
			KillTimer( hMainWnd, 0 );
			if( g_bNProtectAuth )
				KillTimer( hMainWnd, 1 );
			PostQuitMessage(0);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
   }
   return 0;
}

BOOL Script( LPCSTR lpszFileName )
{
	CScanner s;

	if( s.Load( lpszFileName ) )
	{
		s.GetToken();
		while( s.tok != FINISHED )
		{
			if( s.Token == ";" )
			{
				s.GetToken();
				continue;
			}
			else if( s.Token == "DB" )
			{
				s.GetToken();
				strcpy( g_lpDBAddr, s.Token );
			}
			else if( s.Token == "Core" )
			{
				s.GetToken();
				strcpy( g_lpCoreAddr, s.Token );
			}
#ifndef __NEUZ_IPSET
			else if( s.Token == "AddCache" )
			{
				s.GetToken();	// (
				s.GetToken();	// ip
				g_dpLoginSrvr.AddCahce( s.Token );
				s.GetToken();	// )
			}
#endif
#ifndef __NEUZ_MSGVR
			else if( s.Token == "MSG_VER" )
			{
				s.GetToken();
				strcpy( g_szMSG_VER, s.Token );
			}
#endif
			else if( s.Token == "NPROTECT" )
			{
				g_bNProtectAuth = TRUE;
			}
			s.GetToken();
		}

#ifdef __NEUZ_IPSET
		g_dpLoginSrvr.AddCahce(__NEUZ_IPSET);
#endif
#ifndef __NEUZ_MSGVR
		if( g_szMSG_VER[0] == 0 )
			strcpy( g_szMSG_VER, "20040706" );
#else
		strcpy(g_szMSG_VER, __NEUZ_MSGVR);
#endif

		return TRUE;
	}

	Error( "Can't open file, %s.\n", lpszFileName );
	return FALSE;
};
```
