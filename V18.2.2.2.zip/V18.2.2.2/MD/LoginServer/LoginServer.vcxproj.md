# LoginServer.vcxproj

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\LoginServer\LoginServer.vcxproj`
Chemin relatif: `LoginServer\LoginServer.vcxproj`
Nom du fichier: `LoginServer.vcxproj`
Extension originale: `.vcxproj`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```text
<?xml version="1.0" encoding="utf-8"?>
<Project DefaultTargets="Build" xmlns="http://schemas.microsoft.com/developer/msbuild/2003">
  <ItemGroup Label="ProjectConfigurations">
    <ProjectConfiguration Include="Debug|Win32">
      <Configuration>Debug</Configuration>
      <Platform>Win32</Platform>
    </ProjectConfiguration>
    <ProjectConfiguration Include="Release|Win32">
      <Configuration>Release</Configuration>
      <Platform>Win32</Platform>
    </ProjectConfiguration>
  </ItemGroup>
  <PropertyGroup Label="Globals">
    <WindowsTargetPlatformVersion>10.0</WindowsTargetPlatformVersion>
    <VCProjectVersion>16.0</VCProjectVersion>
    <ProjectGuid>{073CA223-A87D-4CC7-AFBF-8A4D022CA502}</ProjectGuid>
  </PropertyGroup>
  <Import Project="$(VCTargetsPath)\Microsoft.Cpp.Default.props" />
  <PropertyGroup Condition="'$(Configuration)|$(Platform)'=='Debug|Win32'" Label="Configuration">
    <ConfigurationType>Application</ConfigurationType>
    <UseDebugLibraries>true</UseDebugLibraries>
    <PlatformToolset>v145</PlatformToolset>
    <CharacterSet>MultiByte</CharacterSet>
  </PropertyGroup>
  <PropertyGroup Condition="'$(Configuration)|$(Platform)'=='Release|Win32'" Label="Configuration">
    <ConfigurationType>Application</ConfigurationType>
    <UseDebugLibraries>false</UseDebugLibraries>
    <PlatformToolset>v145</PlatformToolset>
    <WholeProgramOptimization>true</WholeProgramOptimization>
    <CharacterSet>MultiByte</CharacterSet>
  </PropertyGroup>
  <Import Project="$(VCTargetsPath)\Microsoft.Cpp.props" />
  <ImportGroup Label="ExtensionSettings">
  </ImportGroup>
  <ImportGroup Label="Shared">
  </ImportGroup>
  <ImportGroup Label="PropertySheets" Condition="'$(Configuration)|$(Platform)'=='Debug|Win32'">
    <Import Project="$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props" Condition="exists('$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props')" Label="LocalAppDataPlatform" />
  </ImportGroup>
  <ImportGroup Condition="'$(Configuration)|$(Platform)'=='Release|Win32'" Label="PropertySheets">
    <Import Project="$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props" Condition="exists('$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props')" Label="LocalAppDataPlatform" />
  </ImportGroup>
  <PropertyGroup Label="UserMacros" />
  <PropertyGroup Condition="'$(Configuration)|$(Platform)'=='Debug|Win32'">
    <LinkIncremental>true</LinkIncremental>
    <IntDir>$(SolutionDir)bin\$(Configuration)\$(ProjectName)\int\</IntDir>
    <OutDir>$(SolutionDir)bin\$(Configuration)\$(ProjectName)\</OutDir>
  </PropertyGroup>
  <PropertyGroup Condition="'$(Configuration)|$(Platform)'=='Release|Win32'">
    <LinkIncremental>false</LinkIncremental>
    <IntDir>$(SolutionDir)bin\$(Configuration)\$(ProjectName)\int\</IntDir>
    <OutDir>$(SolutionDir)bin\$(Configuration)\$(ProjectName)\</OutDir>
  </PropertyGroup>
  <ItemDefinitionGroup Condition="'$(Configuration)|$(Platform)'=='Debug|Win32'">
    <ClCompile>
      <AdditionalIncludeDirectories>..\DX_SDK;..\..\Resource;.;..\_Network\Net\Include;..\_Network\Misc\Include;..\_Network\Mcl\Include;..\_network;..\_DirectX;..\_Common;..\ThirdParty\spdlog\include</AdditionalIncludeDirectories>
      <PreprocessorDefinitions>WIN32;_DEBUG;_WINDOWS;_CRT_SECURE_NO_WARNINGS;NO_WARN_MBCS_MFC_DEPRECATION;_WINSOCK_DEPRECATED_NO_WARNINGS</PreprocessorDefinitions>
      <PrecompiledHeader>Use</PrecompiledHeader>
      <PrecompiledHeaderFile>stdafx.h</PrecompiledHeaderFile>
      <WarningLevel>Level3</WarningLevel>
      <SDLCheck>false</SDLCheck>
      <RuntimeLibrary>MultiThreadedDebug</RuntimeLibrary>
      <AdditionalOptions>/Zc:threadSafeInit- %(AdditionalOptions)</AdditionalOptions>
    </ClCompile>
    <Link>
      <AdditionalDependencies>ws2_32.lib;winmm.lib</AdditionalDependencies>
      <AdditionalLibraryDirectories>..\_Network</AdditionalLibraryDirectories>
      <GenerateDebugInformation>true</GenerateDebugInformation>
      <SubSystem>Windows</SubSystem>
    </Link>
    <ResourceCompile>
      <Culture>0x0412</Culture>
    </ResourceCompile>
  </ItemDefinitionGroup>
  <ItemDefinitionGroup Condition="'$(Configuration)|$(Platform)'=='Release|Win32'">
    <ClCompile>
      <AdditionalIncludeDirectories>..\DX_SDK;..\..\Resource;.;..\_Network\Net\Include;..\_Network\Misc\Include;..\_Network\Mcl\Include;..\_network;..\_DirectX;..\_Common;..\ThirdParty\spdlog\include</AdditionalIncludeDirectories>
      <PreprocessorDefinitions>WIN32;NDEBUG;_WINDOWS;_CRT_SECURE_NO_WARNINGS;NO_WARN_MBCS_MFC_DEPRECATION;_WINSOCK_DEPRECATED_NO_WARNINGS</PreprocessorDefinitions>
      <IntrinsicFunctions>true</IntrinsicFunctions>
      <FunctionLevelLinking>true</FunctionLevelLinking>
      <PrecompiledHeader>Use</PrecompiledHeader>
      <PrecompiledHeaderFile>stdafx.h</PrecompiledHeaderFile>
      <WarningLevel>Level1</WarningLevel>
      <SDLCheck>false</SDLCheck>
      <RuntimeLibrary>MultiThreaded</RuntimeLibrary>
      <AdditionalOptions>/Zc:threadSafeInit- %(AdditionalOptions)</AdditionalOptions>
    </ClCompile>
    <Link>
      <AdditionalDependencies>ws2_32.lib;winmm.lib</AdditionalDependencies>
      <AdditionalLibraryDirectories>..\_Network</AdditionalLibraryDirectories>
      <GenerateDebugInformation>DebugFull</GenerateDebugInformation>
      <SubSystem>Windows</SubSystem>
      <EnableCOMDATFolding>
      </EnableCOMDATFolding>
      <OptimizeReferences>
      </OptimizeReferences>
      <LinkTimeCodeGeneration />
      <LinkTimeCodeGenerationObjectFile />
    </Link>
    <ResourceCompile>
      <Culture>0x0412</Culture>
    </ResourceCompile>
  </ItemDefinitionGroup>
  <ItemGroup>
    <ClCompile Include="DPCoreClient.cpp">
    </ClCompile>
    <ClCompile Include="DPDatabaseClient.cpp">
    </ClCompile>
    <ClCompile Include="DPLoginSrvr.cpp">
    </ClCompile>
    <ClCompile Include="LoginProtect.cpp">
    </ClCompile>
    <ClCompile Include="LoginServer.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\memtrace.cpp">
    </ClCompile>
    <ClCompile Include="StdAfx.cpp">
      <PrecompiledHeader Condition="'$(Configuration)|$(Platform)'=='Release|Win32'">Create</PrecompiledHeader>
      <PrecompiledHeader Condition="'$(Configuration)|$(Platform)'=='Debug|Win32'">Create</PrecompiledHeader>
    </ClCompile>
    <ClCompile Include="User.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\misc\src\ar.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\misc\src\dos2.cpp">
    </ClCompile>
    <ClCompile Include="..\_Network\Misc\Src\heapmng.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\misc\src\MyTrace.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\net\src\buffer.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\net\src\clientsock.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\net\src\clientsocke.cpp">
    </ClCompile>
    <ClCompile Include="..\_Network\Net\Src\crc.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\net\src\dpmng.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\net\src\dpsock.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\net\src\serversock.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\net\src\serversocke.cpp">
    </ClCompile>
    <ClCompile Include="..\_network\net\src\sock.cpp">
    </ClCompile>
    <ClCompile Include="..\_DirectX\dxutil.cpp">
    </ClCompile>
    <ClCompile Include="..\_common\debug.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\file.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\timer.cpp">
    </ClCompile>
    <ClCompile Include="..\_Common\vUtil.cpp">
    </ClCompile>
    <ClCompile Include="..\_common\xutil.cpp">
    </ClCompile>
	<ClCompile Include="..\_Common\scanner.cpp">
	</ClCompile>
<ClCompile Include="..\_Common\ZckSpdLog.cpp">
  <PrecompiledHeader>NotUsing</PrecompiledHeader>
  <AdditionalIncludeDirectories>..\ThirdParty\spdlog\include;%(AdditionalIncludeDirectories)</AdditionalIncludeDirectories>
  <AdditionalOptions>/EHsc /utf-8 /Zc:__cplusplus %(AdditionalOptions)</AdditionalOptions>
</ClCompile>
	</ItemGroup>
  <ItemGroup>
    <ResourceCompile Include="LoginServer.rc" />
  </ItemGroup>
  <ItemGroup>
    <ClInclude Include="DPCoreClient.h" />
    <ClInclude Include="DPDatabaseClient.h" />
    <ClInclude Include="DPLoginSrvr.h" />
    <ClInclude Include="LoginProtect.h" />
    <ClInclude Include="LoginServer.h" />
    <ClInclude Include="..\_Common\memtrace.h" />
    <ClInclude Include="resource.h" />
    <ClInclude Include="StdAfx.h" />
    <ClInclude Include="User.h" />
    <ClInclude Include="VersionCommon.h" />
    <ClInclude Include="..\_network\CmnHdr.h" />
    <ClInclude Include="..\_network\ggsrv.h" />
    <ClInclude Include="..\_network\MsgHdr.h" />
    <ClInclude Include="..\_network\misc\include\ar.h" />
    <ClInclude Include="..\_network\misc\include\dos2.h" />
    <ClInclude Include="..\_network\misc\include\heapmng.h" />
    <ClInclude Include="..\_network\misc\include\mempool.h" />
    <ClInclude Include="..\_network\misc\include\MEMPOOLER.H" />
    <ClInclude Include="..\_network\misc\include\memspy.h" />
    <ClInclude Include="..\_network\misc\include\MyMap.h" />
    <ClInclude Include="..\_network\misc\include\MyTrace.h" />
    <ClInclude Include="..\_network\misc\include\ObjMap.h" />
    <ClInclude Include="..\_network\misc\include\tickcount.h" />
    <ClInclude Include="..\_network\mcl\include\cmcl.h" />
    <ClInclude Include="..\_network\mcl\include\cmclautolock.h" />
    <ClInclude Include="..\_network\mcl\include\cmclcritsec.h" />
    <ClInclude Include="..\_network\net\include\buffer.h" />
    <ClInclude Include="..\_network\net\include\clientsock.h" />
    <ClInclude Include="..\_network\net\include\clientsocke.h" />
    <ClInclude Include="..\_network\net\include\crc.h" />
    <ClInclude Include="..\_network\net\include\dpmng.h" />
    <ClInclude Include="..\_network\net\include\dpsock.h" />
    <ClInclude Include="..\_network\net\include\serversock.h" />
    <ClInclude Include="..\_network\net\include\serversocke.h" />
    <ClInclude Include="..\_network\net\include\sock.h" />
    <ClInclude Include="..\_Common\DefineCommon.h" />
    <ClInclude Include="..\_DirectX\dxutil.h" />
    <ClInclude Include="..\_Common\data.h" />
    <ClInclude Include="..\_common\debug.h" />
    <ClInclude Include="..\_Common\file.h" />
    <ClInclude Include="..\_Common\timer.h" />
    <ClInclude Include="..\_Common\vUtil.h" />
    <ClInclude Include="..\_common\xutil.h" />
    <ClInclude Include="..\_Common\scanner.h" />
	<ClInclude Include="..\_Common\ZckSpdLog.h" />
  </ItemGroup>
  <ItemGroup>
    <Image Include="LoginServer.ico" />
    <Image Include="small.ico" />
  </ItemGroup>
  <ItemGroup>
    <None Include="LoginServer.ini" />
  </ItemGroup>
  <Import Project="$(VCTargetsPath)\Microsoft.Cpp.targets" />
  <ImportGroup Label="ExtensionTargets">
  </ImportGroup>
</Project>
```
