# LoginProtect.h

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\LoginServer\LoginProtect.h`
Chemin relatif: `LoginServer\LoginProtect.h`
Nom du fichier: `LoginProtect.h`
Extension originale: `.h`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
// LoginProtect.h: interface for the CLoginProtect class.

////////////////////////////////////////////////////////////////

#if !defined(AFX_LOGINPROTECT_H__818DA819_B42E_4A41_9CEF_53B0C13A0F51__INCLUDED_)
#define AFX_LOGINPROTECT_H__818DA819_B42E_4A41_9CEF_53B0C13A0F51__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#endif // !defined(AFX_LOGINPROTECT_H__818DA819_B42E_4A41_9CEF_53B0C13A0F51__INCLUDED_)
```
