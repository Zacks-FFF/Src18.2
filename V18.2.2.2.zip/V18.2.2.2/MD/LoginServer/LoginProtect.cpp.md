# LoginProtect.cpp

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\LoginServer\LoginProtect.cpp`
Chemin relatif: `LoginServer\LoginProtect.cpp`
Nom du fichier: `LoginProtect.cpp`
Extension originale: `.cpp`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
// LoginProtect.cpp: implementation of the CLoginProtect class.

////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "LoginProtect.h"
```
