# d3dx.h

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\DX_SDK\d3dx.h`
Chemin relatif: `DX_SDK\d3dx.h`
Nom du fichier: `d3dx.h`
Extension originale: `.h`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
///////////////////////////////////////////////////////////////////////////
//
//  Copyright (C) Microsoft Corporation.  All Rights Reserved.
//
//  File:       d3dx.h
//  Content:    D3DX utility library
//
///////////////////////////////////////////////////////////////////////////

#ifndef __D3DX_H__
#define __D3DX_H__

#ifndef D3DXINLINE
#ifdef __cplusplus
#define D3DXINLINE inline
#else
#define D3DXINLINE _inline
#endif
#endif

#include "d3dxcore.h"
#include "d3dxmath.h"
#include "d3dxshapes.h"
#include "d3dxsprite.h"

#endif //__D3DX_H__
```
