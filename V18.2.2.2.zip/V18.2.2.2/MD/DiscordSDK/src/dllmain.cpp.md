# dllmain.cpp

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\DiscordSDK\src\dllmain.cpp`
Chemin relatif: `DiscordSDK\src\dllmain.cpp`
Nom du fichier: `dllmain.cpp`
Extension originale: `.cpp`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
#include "StdAfx.h"
#include <windows.h>

// outsmart GCC's missing-declarations warning
BOOL WINAPI DllMain(HMODULE, DWORD, LPVOID);
BOOL WINAPI DllMain(HMODULE, DWORD, LPVOID)
{
    return TRUE;
}
```
