# QuizDBCtrl.cpp

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\DatabaseServer\QuizDBCtrl.cpp`
Chemin relatif: `DatabaseServer\QuizDBCtrl.cpp`
Nom du fichier: `QuizDBCtrl.cpp`
Extension originale: `.cpp`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
// QuizDBCtrl.cpp: implementation of the CQuizDBCtrl class.

////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "QuizDBCtrl.h"
```
