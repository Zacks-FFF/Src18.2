# DatabaseServer.h

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\DatabaseServer\DatabaseServer.h`
Chemin relatif: `DatabaseServer\DatabaseServer.h`
Nom du fichier: `DatabaseServer.h`
Extension originale: `.h`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp

#if !defined(AFX_DATABASESERVER_H__588B3C35_83E7_43AD_A3DB_26B95B8A3AEA__INCLUDED_)
#define AFX_DATABASESERVER_H__588B3C35_83E7_43AD_A3DB_26B95B8A3AEA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//#include "resource.h"

#endif // !defined(AFX_DATABASESERVER_H__588B3C35_83E7_43AD_A3DB_26B95B8A3AEA__INCLUDED_)
```
