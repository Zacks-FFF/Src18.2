# AccountTimeLimitDBCtrl.cpp

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\DatabaseServer\AccountTimeLimitDBCtrl.cpp`
Chemin relatif: `DatabaseServer\AccountTimeLimitDBCtrl.cpp`
Nom du fichier: `AccountTimeLimitDBCtrl.cpp`
Extension originale: `.cpp`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
// AccountTimeLimitDBCtrl.cpp: implementation of the CAccountTimeLimitDBCtrl class.

////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "AccountTimeLimitDBCtrl.h"
```
