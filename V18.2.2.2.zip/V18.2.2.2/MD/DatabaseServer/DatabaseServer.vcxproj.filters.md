# DatabaseServer.vcxproj.filters

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\DatabaseServer\DatabaseServer.vcxproj.filters`
Chemin relatif: `DatabaseServer\DatabaseServer.vcxproj.filters`
Nom du fichier: `DatabaseServer.vcxproj.filters`
Extension originale: `.filters`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```text
<?xml version="1.0" encoding="utf-8"?>
<Project ToolsVersion="4.0" xmlns="http://schemas.microsoft.com/developer/msbuild/2003">
  <ItemGroup>
    <Filter Include="Source Files">
      <UniqueIdentifier>{53cfd359-f4e6-4f55-8a39-079f192c9be3}</UniqueIdentifier>
      <Extensions>cpp;c;cxx;rc;def;r;odl;idl;hpj;bat</Extensions>
    </Filter>
    <Filter Include="Header Files">
      <UniqueIdentifier>{3cbe9654-56c9-4e90-992b-4351dfc71d47}</UniqueIdentifier>
      <Extensions>h;hpp;hxx;hm;inl</Extensions>
    </Filter>
    <Filter Include="Resource Files">
      <UniqueIdentifier>{c5e0cd63-bcc0-4237-9056-41fd500a0672}</UniqueIdentifier>
      <Extensions>ico;cur;bmp;dlg;rc2;rct;bin;rgs;gif;jpg;jpeg;jpe</Extensions>
    </Filter>
    <Filter Include="Network Files">
      <UniqueIdentifier>{83bd5517-1b8a-4f61-a309-a45d0143267e}</UniqueIdentifier>
    </Filter>
    <Filter Include="Network Files\Misc">
      <UniqueIdentifier>{78676b08-ea68-4047-82cf-b329288ffe20}</UniqueIdentifier>
    </Filter>
    <Filter Include="Network Files\Mcl">
      <UniqueIdentifier>{bf9c2446-f6f7-4b4b-9376-0e218daf03d7}</UniqueIdentifier>
    </Filter>
    <Filter Include="Network Files\Net">
      <UniqueIdentifier>{503de86a-8cc1-4aaf-9d87-defdbc8d7141}</UniqueIdentifier>
    </Filter>
    <Filter Include="Network Files\NetObjects">
      <UniqueIdentifier>{93ae1139-c163-4a65-86a0-511345345323}</UniqueIdentifier>
    </Filter>
    <Filter Include="Neuz Files">
      <UniqueIdentifier>{af9f88c4-3358-4d54-9175-7a51c9344835}</UniqueIdentifier>
    </Filter>
    <Filter Include="Neuz Files\DirectX Files">
      <UniqueIdentifier>{828e709d-a758-417d-b799-877ec66c7a99}</UniqueIdentifier>
    </Filter>
    <Filter Include="Neuz Files\Common Files">
      <UniqueIdentifier>{5c70d1e3-9554-4b9d-b68c-6cdf1cefaa40}</UniqueIdentifier>
    </Filter>
    <Filter Include="Neuz Files\Common Files\Script">
      <UniqueIdentifier>{6b2f033a-9683-4721-9263-f1b8bb5b99b7}</UniqueIdentifier>
    </Filter>
    <Filter Include="Neuz Files\Common Files\Objects">
      <UniqueIdentifier>{7d64f0ca-7a76-488b-9e96-e1f24daa4dd5}</UniqueIdentifier>
    </Filter>
    <Filter Include="Neuz Files\Interface">
      <UniqueIdentifier>{d008b67a-8a63-4da5-a93a-931d5946dced}</UniqueIdentifier>
    </Filter>
    <Filter Include="Database Files">
      <UniqueIdentifier>{d3660a0d-08f0-485d-b2d9-1e53727498df}</UniqueIdentifier>
    </Filter>
  </ItemGroup>
  <ItemGroup>
    <ClCompile Include="..\_Database\AccountCacheMgr.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="AccountTimeLimitDBCtrl.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="CampusDBCtrl.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\Continent.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="couplehelper.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="DatabaseServer.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="dbcontroller.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="dpaccountclient.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="DPCoreSrvr.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="DPLoginSrvr.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="dptrans.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="GuildHouseDBCtrl.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\Housing.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="HousingDBCtrl.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="lordskillexecutable.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\memtrace.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\pocket.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="Project.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="QuizDBCtrl.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="RainbowRaceDBCtrl.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\rtmessenger.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="SecretRoomDBMng.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="StdAfx.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\Tax.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="tlord.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_common\vutil.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\misc\src\ar.cpp">
      <Filter>Network Files\Misc</Filter>
    </ClCompile>
    <ClCompile Include="..\_Network\Misc\Src\heapmng.cpp">
      <Filter>Network Files\Misc</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\misc\src\MyTrace.cpp">
      <Filter>Network Files\Misc</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net\src\buffer.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net\src\clientsock.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net\src\clientsocke.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net\src\dpmng.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net\src\dpsock.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net\src\serversock.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net\src\serversocke.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\net\src\sock.cpp">
      <Filter>Network Files\Net</Filter>
    </ClCompile>
    <ClCompile Include="..\_network\objects\Obj.cpp">
      <Filter>Network Files\NetObjects</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\langman.cpp">
      <Filter>Neuz Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\path.cpp">
      <Filter>Neuz Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\xutil.cpp">
      <Filter>Neuz Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_DirectX\dxutil.cpp">
      <Filter>Neuz Files\DirectX Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\buff.cpp">
      <Filter>Neuz Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\Campus.cpp">
      <Filter>Neuz Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\couple.cpp">
      <Filter>Neuz Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_common\debug.cpp">
      <Filter>Neuz Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\EventLua.cpp">
      <Filter>Neuz Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\file.cpp">
      <Filter>Neuz Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\FunnyCoin.cpp">
      <Filter>Neuz Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_common\guild.cpp">
      <Filter>Neuz Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\GuildCombat1to1.cpp">
      <Filter>Neuz Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\GuildHouse.cpp">
      <Filter>Neuz Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_common\guildquest.cpp">
      <Filter>Neuz Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_common\guildwar.cpp">
      <Filter>Neuz Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\honor.cpp">
      <Filter>Neuz Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\lord.cpp">
      <Filter>Neuz Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\lordskill.cpp">
      <Filter>Neuz Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\LuaBase.cpp">
      <Filter>Neuz Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\messenger.cpp">
      <Filter>Neuz Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\piercing.cpp">
      <Filter>Neuz Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\playerdata.cpp">
      <Filter>Neuz Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\post.cpp">
      <Filter>Neuz Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\ProjectCmn.cpp">
      <Filter>Neuz Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\Quiz.cpp">
      <Filter>Neuz Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\serialnumber.cpp">
      <Filter>Neuz Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\SkillInfluence.cpp">
      <Filter>Neuz Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\spevent.cpp">
      <Filter>Neuz Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\timer.cpp">
      <Filter>Neuz Files\Common Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\scanner.cpp">
      <Filter>Neuz Files\Common Files\Script</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\script.cpp">
      <Filter>Neuz Files\Common Files\Script</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\ObjSerialize.cpp">
      <Filter>Neuz Files\Common Files\Objects</Filter>
    </ClCompile>
    <ClCompile Include="..\_common\ObjSerializeOpt.cpp">
      <Filter>Neuz Files\Common Files\Objects</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\pet.cpp">
      <Filter>Neuz Files\Common Files\Objects</Filter>
    </ClCompile>
    <ClCompile Include="..\_Interface\UserTaskBar.cpp">
      <Filter>Neuz Files\Interface</Filter>
    </ClCompile>
    <ClCompile Include="..\_Database\DBBackEndSystem.cpp">
      <Filter>Database Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Database\DBConvert.cpp">
      <Filter>Database Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Database\DBConvertNew.cpp">
      <Filter>Database Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Database\DbItemUpdate.cpp">
      <Filter>Database Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_database\DbManager.cpp">
      <Filter>Database Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Database\DbManagerFun.cpp">
      <Filter>Database Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Database\DbManagerJoin.cpp">
      <Filter>Database Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Database\DbManagerLog.cpp">
      <Filter>Database Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Database\DbManagerSave.cpp">
      <Filter>Database Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Database\des.c">
      <Filter>Database Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_database\Query.cpp">
      <Filter>Database Files</Filter>
    </ClCompile>
    <ClCompile Include="..\WorldServer\MiniDumper.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\FlyFFShop.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\Switches.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\RecordBook.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\MonsterAlbum.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\Buyback.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\SeasonPass.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\Wardrobe.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\StarterItems.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\PlayerStatue.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\ZckAchievement.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
    <ClCompile Include="..\_Common\ZckClassementDonjon.cpp">
      <Filter>Source Files</Filter>
    </ClCompile>
  </ItemGroup>
  <ItemGroup>
    <ClInclude Include="..\_Database\AccountCacheMgr.h">
      <Filter>Source Files</Filter>
    </ClInclude>
    <ClInclude Include="AccountTimeLimitDBCtrl.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="CampusDBCtrl.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="couplehelper.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="DatabaseServer.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="dbcontroller.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="DefineConMode.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="dpaccountclient.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="DPCoreSrvr.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="DPLoginSrvr.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="dptrans.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="GuildHouseDBCtrl.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\Housing.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="HousingDBCtrl.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="lordskillexecutable.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\memtrace.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\pocket.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="project.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="QuizDBCtrl.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="RainbowRaceDBCtrl.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\rtmessenger.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="SecretRoomDBMng.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="StdAfx.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="tlord.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="VersionCommon.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="resource.h">
      <Filter>Resource Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\CmnHdr.h">
      <Filter>Network Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\MsgHdr.h">
      <Filter>Network Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\ar.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\heapmng.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\mempool.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\MEMPOOLER.H">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\memspy.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\Misc.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\MyMap.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\misc\include\MyTrace.h">
      <Filter>Network Files\Misc</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\mcl\include\cmcl.h">
      <Filter>Network Files\Mcl</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\mcl\include\cmclautolock.h">
      <Filter>Network Files\Mcl</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\mcl\include\cmclcritsec.h">
      <Filter>Network Files\Mcl</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\buffer.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\clientsock.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\clientsocke.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\dpmng.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\dpsock.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\serversock.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\serversocke.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\net\include\sock.h">
      <Filter>Network Files\Net</Filter>
    </ClInclude>
    <ClInclude Include="..\_network\objects\Obj.h">
      <Filter>Network Files\NetObjects</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\DefineCommon.h">
      <Filter>Neuz Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\langman.h">
      <Filter>Neuz Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\patch.h">
      <Filter>Neuz Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\xutil.h">
      <Filter>Neuz Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_DirectX\dxutil.h">
      <Filter>Neuz Files\DirectX Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\authorization.h">
      <Filter>Neuz Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\buff.h">
      <Filter>Neuz Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_common\buyinginfo.h">
      <Filter>Neuz Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\Campus.h">
      <Filter>Neuz Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\data.h">
      <Filter>Neuz Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_common\debug.h">
      <Filter>Neuz Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\EventLua.h">
      <Filter>Neuz Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\file.h">
      <Filter>Neuz Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\FunnyCoin.h">
      <Filter>Neuz Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_common\guild.h">
      <Filter>Neuz Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\GuildCombat1to1.h">
      <Filter>Neuz Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\GuildHouse.h">
      <Filter>Neuz Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_common\guildquest.h">
      <Filter>Neuz Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_common\guildwar.h">
      <Filter>Neuz Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\lord.h">
      <Filter>Neuz Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\lordskill.h">
      <Filter>Neuz Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\LuaBase.h">
      <Filter>Neuz Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\messenger.h">
      <Filter>Neuz Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_common\party.h">
      <Filter>Neuz Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_common\path.h">
      <Filter>Neuz Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\Piercing.h">
      <Filter>Neuz Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\playerdata.h">
      <Filter>Neuz Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\post.h">
      <Filter>Neuz Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\ProjectCmn.h">
      <Filter>Neuz Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\Quiz.h">
      <Filter>Neuz Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\serialnumber.h">
      <Filter>Neuz Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\SkillInfluence.h">
      <Filter>Neuz Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\spevent.h">
      <Filter>Neuz Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\timer.h">
      <Filter>Neuz Files\Common Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\scanner.h">
      <Filter>Neuz Files\Common Files\Script</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\script.h">
      <Filter>Neuz Files\Common Files\Script</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\pet.h">
      <Filter>Neuz Files\Common Files\Objects</Filter>
    </ClInclude>
    <ClInclude Include="..\_Interface\UserTaskBar.h">
      <Filter>Neuz Files\Interface</Filter>
    </ClInclude>
    <ClInclude Include="..\_database\DbManager.h">
      <Filter>Database Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Database\des.h">
      <Filter>Database Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_database\Query.h">
      <Filter>Database Files</Filter>
    </ClInclude>
    <ClInclude Include="..\WorldServer\MiniDumper.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\FlyFFShop.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\Switches.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\RecordBook.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\RecordParameters.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\MonsterAlbum.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\Buyback.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\SeasonPass.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\Wardrobe.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\StarterItems.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\PlayerStatue.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\ZckAchievement.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\ZckPrestige.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\ZckAura.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\ZckPetGlow.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\ZckTrails.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\ZckElementRgb.h">
      <Filter>Header Files</Filter>
    </ClInclude>
    <ClInclude Include="..\_Common\ZckClassementDonjon.h">
      <Filter>Header Files</Filter>
    </ClInclude>
  </ItemGroup>
  <ItemGroup>
    <Image Include="DatabaseServer.ico">
      <Filter>Resource Files</Filter>
    </Image>
    <Image Include="small.ico">
      <Filter>Resource Files</Filter>
    </Image>
  </ItemGroup>
  <ItemGroup>
    <None Include="databaseserver.ini">
      <Filter>Resource Files</Filter>
    </None>
  </ItemGroup>
  <ItemGroup>
    <ResourceCompile Include="DatabaseServer.rc">
      <Filter>Resource Files</Filter>
    </ResourceCompile>
  </ItemGroup>
</Project>
```
