# RainbowRaceDBCtrl.cpp

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\DatabaseServer\RainbowRaceDBCtrl.cpp`
Chemin relatif: `DatabaseServer\RainbowRaceDBCtrl.cpp`
Nom du fichier: `RainbowRaceDBCtrl.cpp`
Extension originale: `.cpp`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
#include "stdafx.h"
#include ".\rainbowracedbctrl.h"
```
