# AccountTimeLimitDBCtrl.h

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\DatabaseServer\AccountTimeLimitDBCtrl.h`
Chemin relatif: `DatabaseServer\AccountTimeLimitDBCtrl.h`
Nom du fichier: `AccountTimeLimitDBCtrl.h`
Extension originale: `.h`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
// AccountTimeLimitDBCtrl.h: interface for the CAccountTimeLimitDBCtrl class.

////////////////////////////////////////////////////////////////

#if !defined(AFX_ACCOUNTTIMELIMITDBCTRL_H__E4562E24_E4DE_4E80_8150_E1F1E2F6C4AA__INCLUDED_)
#define AFX_ACCOUNTTIMELIMITDBCTRL_H__E4562E24_E4DE_4E80_8150_E1F1E2F6C4AA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#endif // !defined(AFX_ACCOUNTTIMELIMITDBCTRL_H__E4562E24_E4DE_4E80_8150_E1F1E2F6C4AA__INCLUDED_)
```
