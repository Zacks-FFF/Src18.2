# CampusDBCtrl.cpp

Chemin original: `C:\Users\rdiff\Desktop\V18.2\Source\DatabaseServer\CampusDBCtrl.cpp`
Chemin relatif: `DatabaseServer\CampusDBCtrl.cpp`
Nom du fichier: `CampusDBCtrl.cpp`
Extension originale: `.cpp`
Mode lecture: `texte`
Encodage: `utf-8-sig`

```cpp
// CampusDBCtrl.cpp: implementation of the CCampusDBCtrl class.

////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "CampusDBCtrl.h"
```
